function color_change(id,number){
    if(number < 11){
        document.getElementById(id).style.backgroundColor = '#ead23b';
    }else if(number < 21){
        document.getElementById(id).style.backgroundColor = '#47a6e9';
    }else if(number < 31){
        document.getElementById(id).style.backgroundColor = '#ed5543';
    }else if(number < 41){
        document.getElementById(id).style.backgroundColor = '#555555';
    }else if(number <= 45){
        document.getElementById(id).style.backgroundColor = '#69c844';
    }
}

function numberWithCommas(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

function getLottoNum(drwNo) {
    let url = '';
    if (drwNo) {
        url = jQuery("#lotto_winner_number").attr("api_url")+"?drwNo="+drwNo;
    } else {
        url = jQuery("#lotto_winner_number").attr("api_url");
    }
    jQuery.ajax({
        type: "GET",
        url: url,
        complete: function(xhr, status, error){
            if (xhr.responseText != "null") {
                var jsonData = JSON.parse(xhr.responseText);
                if (jsonData.returnValue == "success") {
                    jQuery('#ln_year').text(jsonData.drwNoDate.substring(0,4));
                    jQuery('#ln_month').text(jsonData.drwNoDate.substring(5,7));
                    jQuery('#ln_date').text(jsonData.drwNoDate.substring(8));
                    jQuery('#ln_number').text(jsonData.drwNo);
                    jQuery('#first_number').text(jsonData.drwtNo1);
                    jQuery('#second_number').text(jsonData.drwtNo2);
                    jQuery('#third_number').text(jsonData.drwtNo3);
                    jQuery('#fourth_number').text(jsonData.drwtNo4);
                    jQuery('#fifth_number').text(jsonData.drwtNo5);
                    jQuery('#sixth_number').text(jsonData.drwtNo6);
                    jQuery('#seventh_number').text(jsonData.bnusNo);
                    jQuery('#winner').text(jsonData.firstPrzwnerCo);
                    jQuery('#winner_money').text(numberWithCommas(jsonData.firstWinamnt));

                    color_change('first_number', jsonData.drwtNo1);
                    color_change('second_number', jsonData.drwtNo2);
                    color_change('third_number', jsonData.drwtNo3);
                    color_change('fourth_number', jsonData.drwtNo4);
                    color_change('fifth_number', jsonData.drwtNo5);
                    color_change('sixth_number', jsonData.drwtNo6);
                    color_change('seventh_number', jsonData.bnusNo);
                }
            } else {
                alert('없는 회차입니다.')
            }
            return true;
        }
    });
}


getLottoNum();

jQuery('#left').click(function(){
    drwNo = parseInt(jQuery('#ln_number').text());
    drwNo--;
    getLottoNum(drwNo);
});

jQuery('#right').click(function(){
    drwNo = parseInt(jQuery('#ln_number').text());
    drwNo++;
    getLottoNum(drwNo);
});