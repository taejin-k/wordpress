jQuery("#button_popup").on("click", function(){
    
    if (!jQuery("#PHONE_POPUP").val()) {
        alert("휴대폰번호를 입력해 주세요");
        jQuery("#PHONE_POPUP").focus();
    } else if (!jQuery("#NAME_POPUP").val()) {
        alert("이름을 입력해 주세요");
        jQuery("#NAME_POPUP").focus();
    } else {
        jQuery("#button_popup").attr("disabled", true);

        jQuery.ajax({
        type: "POST",
        url: "https://lottogoal.co.kr/join_module.php",
        data: {
            "mode": "ok",
            "cmpny": "powerlotto",
            "PHONE": jQuery("#PHONE_POPUP").val(),
            "NAME": jQuery("#NAME_POPUP").val(),
            "AGE": 0
        },
        complete: function(xhr, status, error){
            var jsonData = JSON.parse(xhr.responseText);
                alert(jsonData.data.result_msg);
            
                // 성공 처리
                if (jsonData.data.code == "000000") {
                    gtag('event', 'join');
                    var hp = jQuery("#PHONE_POPUP").val();
                    window.location = jQuery("#lotto_free_number_popup").attr("api_url")+'&hp='+hp;
                    
                // 실패 처리
                } else {
                    gtag('event', 'join_fail');
                    jQuery("#button_popup").attr("disabled", false);
                    jQuery("#PHONE_POPUP").focus();
                }
            
            return true;
        },
            
        dataType: "text"
            
        });
    }
});

jQuery(window).scroll(function(){
    if(jQuery(document).height() == (jQuery('.lotto_free_number_popup').offset().top + jQuery('.lotto_free_number_popup').height())){
        jQuery('.lotto_free_number_popup').fadeOut(); 
    }else{
        jQuery('.lotto_free_number_popup').fadeIn(); 
    }
});