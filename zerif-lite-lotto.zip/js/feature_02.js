let box_02 = jQuery('#features_02 > div > div.h-row-container.gutters-row-lg-2.gutters-row-md-2.gutters-row-2.gutters-row-v-lg-2.gutters-row-v-md-2.gutters-row-v-2.style-627.style-local-5-c43.position-relative > div > div')

function box_width_02(){
    if(box_02.length == 4){
        box_02.css('flex', '0 0 25%');
        box_02.css('width', '25%');
        box_02.css('min-width', '400px');
        box_02.css('max-width', '400px');
    }else if(box_02.length == 3){
        box_02.css('flex', '0 0 33.33333%');
        box_02.css('width', '33.33333%');
        box_02.css('min-width', '400px');
        box_02.css('max-width', '400px');
    }else{
        box_02.css('min-width', '400px');
        box_02.css('max-width', '400px');
    }
}

box_width_02()

jQuery(document).ready(function ($) {
    function media_upload(button_selector) {
        var _custom_media = true,
        _orig_send_attachment = wp.media.editor.send.attachment;
        $('body').on('click', button_selector, function () {
            var button_id = $(this).attr('id');
            wp.media.editor.send.attachment = function (props, attachment) {
                if (_custom_media) {
                    $('.' + button_id + '_img').attr('src', attachment.url);
                    $('.' + button_id + '_url').val(attachment.url);
                } else {
                    return _orig_send_attachment.apply($('#' + button_id), [props, attachment]);
                }
            }
            wp.media.editor.open($('#' + button_id));
            return false;
        });
    }
    media_upload('.js_custom_upload_media');
});
