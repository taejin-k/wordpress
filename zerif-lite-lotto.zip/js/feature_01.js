let box_01 = jQuery('#features_01 > div > div.h-row-container.gutters-row-lg-2.gutters-row-md-2.gutters-row-2.gutters-row-v-lg-2.gutters-row-v-md-2.gutters-row-v-2.style-613.style-local-5-c13.position-relative > div > div')

function box_width_01(){
    if(box_01.length == 4){
        box_01.css('flex', '0 0 25%');
        box_01.css('width', '25%');
        box_01.css('min-width', '400px');
        box_01.css('max-width', '400px');
    }else if(box_01.length == 3){
        box_01.css('flex', '0 0 33.33333%');
        box_01.css('width', '33.33333%');
        box_01.css('min-width', '400px');
        box_01.css('max-width', '400px');
    }else{
        box_01.css('min-width', '400px');
        box_01.css('max-width', '400px');
    }
}

box_width_01()
