function preventD(a){
    a.click(function(event){
        event.preventDefault();
    });
}
function aniLink(link){
    var target = jQuery(link.attr('href')).offset().top-73;
    jQuery('html,body').stop().animate({scrollTop:target},800,'swing');
}

preventD(jQuery('.preventD'));
jQuery('.preventD').on("click", function(){
    aniLink(jQuery(this));
});