jQuery("#button").on("click", function(){
    
    if (!jQuery("#PHONE").val()) {
        alert("휴대폰번호를 입력해 주세요");
        jQuery("#PHONE").focus();
    } else if (!jQuery("#NAME").val()) {
        alert("이름을 입력해 주세요");
        jQuery("#NAME").focus();
    } else {
        jQuery("#button").attr("disabled", true);

        jQuery.ajax({
        type: "POST",
        url: "https://lottogoal.co.kr/join_module.php",
        data: {
            "mode": "ok",
            "cmpny": "lottoanalysis",
            "PHONE": jQuery("#PHONE").val(),
            "NAME": jQuery("#NAME").val(),
            "AGE": 0
        },
        complete: function(xhr, status, error){
            var jsonData = JSON.parse(xhr.responseText);
                alert(jsonData.data.result_msg);
            
                // 성공 처리
                if (jsonData.data.code == "000000") {
                    gtag('event', 'join');
                    var hp = jQuery("#PHONE").val();
                    window.location = jQuery("#lotto_free_number").attr("api_url")+'&hp='+hp;
                
                // 실패 처리
                } else {
                    gtag('event', 'join_fail');
                    jQuery("#button").attr("disabled", false);
                    jQuery("#PHONE").focus();
                }
            
            return true;
        },
            
        dataType: "text"
            
        });
    }
});
