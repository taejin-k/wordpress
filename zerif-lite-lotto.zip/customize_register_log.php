<?php

function customize_register_log($wp_customize){
    
	file_log(__FILE__, __LINE__, __FUNCTION__, '================================================================================' );

	$old_ms = get_option('keultae_cr');
	$cur_ms = microtime(true);
	$diff_ms = $cur_ms - $old_ms;
	update_option('keultae_cr', $cur_ms);
    
	file_log(__FILE__, __LINE__, __FUNCTION__, 'old_ms='.$old_ms.', cur_ms='.$cur_ms.', diff_ms='.$diff_ms);
	if($diff_ms > 3.0){
		file_log(__FILE__, __LINE__, __FUNCTION__, 'panel 목록을 저장: ');
		$panel_a = array();
		$index = 1;
    	foreach($wp_customize->panels() as $key => $obj){
			$panel_a[$key] = array( 'title' => $obj->title, 'priority' => $obj->priority);
			file_log(__FILE__, __LINE__, __FUNCTION__, sprintf('  - %-2d key: %-40s, priority: %-3d, title: %s', $index, $key, $obj->priority, $obj->title));
			$index++;
		}
		update_option('keultae_panel_a',  $panel_a);
        
		file_log(__FILE__, __LINE__, __FUNCTION__, 'section 목록을 저장: ');
		$section_a = array();
		$index = 1;
    	foreach( $wp_customize->sections() as $key => $obj){
			if(empty($obj->panel)){
				$section_a[$key] = array('title' => $obj->title, 'priority' => $obj->priority);
				file_log(__FILE__, __LINE__, __FUNCTION__, sprintf('  - %-2d key: %-40s, priority: %-3d, title: %s', $index, $key, $obj->priority, $obj->title));
				$index++;
			}
		}
		update_option('keultae_section_a',  $section_a);

	}else{
		file_log(__FILE__, __LINE__, __FUNCTION__, '비교 시간이 3초 미만');
		file_log(__FILE__, __LINE__, __FUNCTION__, 'panel 목록을 가져옴: ');
		$panel_a = get_option('keultae_panel_a');
		$index = 1;
		foreach( $panel_a as $key => $obj ) {
			file_log(__FILE__, __LINE__, __FUNCTION__, sprintf('  - %-2d key: %-40s, priority: %-3d, title: %s', $index, $key, $obj['priority'], $obj['title']));
			$index++;
		}

		file_log(__FILE__, __LINE__, __FUNCTION__, 'section 목록을 가져옴: ');
		$section_a = get_option('keultae_section_a');
		$index = 1;
		foreach($section_a as $key => $obj){
			file_log(__FILE__, __LINE__, __FUNCTION__, sprintf('  - %-2d key: %-40s, priority: %-3d, title: %s', $index, $key, $obj['priority'], $obj['title']));
			$index++;
		}
	}

	$wp_customize->add_section('loc_change' , array(
		'title' => '위치 이동',	
	));

	$index = 1;
	foreach( $panel_a as $key => $obj ) {
		$id = 'lcp_'.$key;
		$wp_customize->add_setting( $id,
			array(
				'transport' => 'postMessage',
				'default' => $obj['title'],
			)
		);
		$wp_customize->add_control(
			new WP_Customize_Control( $wp_customize, $id,
				array(
					'label' => 'panel '.$index.' priority: '.$obj['priority'],
					'type' => 'text',
				 	'capability' => 'edit_theme_options',
					'section' => 'loc_change',
					'settings'=> $id,
				)
			)
		);

		$index++;
	}

	$index = 1;
	foreach($section_a as $key => $obj){
		$id = 'lcs_'.$key;
		$wp_customize->add_setting($id,
			array(
				'transport' => 'postMessage',
				'default' => $obj['title'],
			)
		);
		$wp_customize->add_control(
			new WP_Customize_Control($wp_customize, $id,
				array(
					'label' => 'section '.$index.' priority: '.$obj['priority'],
					'type' => 'text',
				 	'capability' => 'edit_theme_options',
					'section' => 'loc_change',
					'settings'=> $id,
				)
			)
		);
		$index++;
	}
}

add_action('customize_register', 'customize_register_log', 2000);