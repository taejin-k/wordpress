<?php

function customize_register_lotto_free_number_popup($wp_customize){
	file_log(__FILE__, __LINE__, __FUNCTION__, 'begin ');
    
    // 로또 -> 무료번호받기 팝업
	$wp_customize->add_section('lotto|free_number_popup',
		array(
			'title' => '무료번호받기 팝업',
			'description' => '무료번호받기 팝업 관련 설정을 합니다.',
			'panel' => 'lotto',
		)
	);
    
    // 로또 -> 무료번호받기 팝업 -> 숨기기
	$wp_customize->add_setting('lotto|free_number_popup|hide',
		array(
			'transport' => 'postMessage',
			'default' => false,
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'lotto|free_number_popup|hide',
			array(
				'label' => '숨기기',
				'type' => 'checkbox',
				'section' => 'lotto|free_number_popup',
				'settings'=> 'lotto|free_number_popup|hide',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('lotto|free_number_popup|hide',
		array(
			'selector' => 'section.lotto_free_number_popup_hide',
			'settings' => 'lotto|free_number_popup|hide',
			'render_callback' => function() {
				return get_theme_mod('lotto|free_number_popup|hide');
			},
		)
	);
    
    // 로또 -> 무료번호받기 팝업 -> 전송버튼
	$wp_customize->add_setting('lotto|free_number_popup|submit',
		array(
			'transport' => 'postMessage',
			'default' => '실시간 무료번호 받기',
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control( $wp_customize, 'lotto|free_number_popup|submit',
			array(
				'label' => '전송 버튼 텍스트',
				'type' => 'text',
				'section' => 'lotto|free_number_popup',
				'settings'=> 'lotto|free_number_popup|submit',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('lotto|free_number_popup|submit',
		array(
			'selector' => 'p.lotto_free_number_popup_submit',
			'settings' => 'lotto|free_number_popup|submit',
			'render_callback' => function() {
				return get_theme_mod('lotto|free_number_popup|submit');
			},
		)
	);
    
    // 로또 -> 무료번호받기 팝업 -> API URL
	$wp_customize->add_setting('lotto|free_number_popup|api_url',
		array(
			'default' => 'https://free.onedaynice.co.kr/complete.php?cmpny=lottoanalysis&to=b'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'lotto|free_number_popup|api_url',
			array(
				'label' => 'API URL',
				'description' => '사용자 정보를 저장할 API URL을 입력해주세요',
				'type' => 'text',
				'section' => 'lotto|free_number_popup',
				'settings'=> 'lotto|free_number_popup|api_url',
			)
		)
	);
    
}

add_action('customize_register', 'customize_register_lotto_free_number_popup');


function after_setup_theme_lotto_free_number_popup(){
    
	function lotto_free_number_popup_scripts(){
	  wp_enqueue_style('lotto_free_number_popup', get_stylesheet_directory_uri().'/style/css/lotto_free_number_popup.css');
	  wp_enqueue_script('lotto_free_number_popup', get_stylesheet_directory_uri().'/js/lotto_free_number_popup.js', array(), false, true);
	}
    
	add_action('wp_enqueue_scripts', 'lotto_free_number_popup_scripts', 101);
	
	function lotto_free_number_popup_action(){
        $cnt = did_action('zerif_after_header');
        if( $cnt == 1 ) {
            get_template_part('sections/lotto_free_number_popup');
        }
	}
	
	add_action('zerif_after_header',  'lotto_free_number_popup_action');
}

add_action('after_setup_theme', 'after_setup_theme_lotto_free_number_popup');
