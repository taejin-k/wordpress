<?php

function customize_register_lotto_free_number($wp_customize){
	file_log(__FILE__, __LINE__, __FUNCTION__, 'begin ');
    
    // 로또 -> 무료번호받기
	$wp_customize->add_section('lotto|free_number',
		array(
			'title' => '무료번호받기',
			'description' => '무료번호받기 관련 설정을 합니다.',
			'panel' => 'lotto',
		)
	);
    
    // 로또 -> 무료번호받기 -> 숨기기
	$wp_customize->add_setting('lotto|free_number|hide',
		array(
			'transport' => 'postMessage',
			'default' => false,
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'lotto|free_number|hide',
			array(
				'label' => '숨기기',
				'type' => 'checkbox',
				'section' => 'lotto|free_number',
				'settings'=> 'lotto|free_number|hide',
			)
		)
	);
    $wp_customize->selective_refresh->add_partial('lotto|free_number|hide',
		array(
			'selector' => 'section.lotto_free_number_hide',
			'settings' => 'lotto|free_number|hide',
			'render_callback' => function() {
				return get_theme_mod('lotto|free_number|hide');
			},
		)
	);

	// 로또 -> 무료번호받기 -> 제목
	$wp_customize->add_setting('lotto|free_number|title',
		array(
			'transport' => 'postMessage',
			'default' => '실시간 무료번호 받기'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'lotto|free_number|title',
			array(
				'label' => '제목',
				'type' => 'text',
				'section' => 'lotto|free_number',
				'settings'=> 'lotto|free_number|title',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('lotto|free_number|title',
		array(
			'selector' => 'p.lotto_free_number_title',
			'settings' => 'lotto|free_number|title',
			'render_callback' => function() {
				return get_theme_mod('lotto|free_number|title');
			},
		)
	);
    
    // 로또 -> 무료번호받기 -> 제목 색깔
	$wp_customize->add_setting('lotto|free_number|title_color',
		array(
			'default' => '#fff'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control($wp_customize, 'lotto|free_number|title_color',
			array(
				'label' => '제목 색깔',
				'section' => 'lotto|free_number',
				'settings'=> 'lotto|free_number|title_color',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('lotto|free_number|title_color',
		array(
			'selector' => 'p.lotto_free_number_title_color',
			'settings' => 'lotto|free_number|title_color',
		)
	);

	// 로또 -> 무료번호받기 -> 부제목
	$wp_customize->add_setting( 'lotto|free_number|sub_title',
		array(
			'transport' => 'postMessage',
			'default' => '지금 당신의 행운번호를 만나보세요.'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'lotto|free_number|sub_title',
			array(
				'label' => '부제목',
				'type' => 'text',
				'section' => 'lotto|free_number',
				'settings'=> 'lotto|free_number|sub_title',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('lotto|free_number|sub_title',
		array(
			'selector' => 'p.lotto_free_number_sub_title',
			'settings' => 'lotto|free_number|sub_title',
			'render_callback' => function() {
				return get_theme_mod('lotto|free_number|sub_title');
			},
		)
	);
    
    // 로또 -> 무료번호받기 -> 부제목 색깔
	$wp_customize->add_setting('lotto|free_number|sub_title_color',
		array(
			'default' => '#fff'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control($wp_customize, 'lotto|free_number|sub_title_color',
			array(
				'label' => '부제목 색깔',
				'section' => 'lotto|free_number',
				'settings'=> 'lotto|free_number|sub_title_color',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('lotto|free_number|sub_title_color',
		array(
			'selector' => 'p.lotto_free_number_sub_title_color',
			'settings' => 'lotto|free_number|sub_title_color',
		)
	);
    
    // 로또 -> 무료번호받기 -> 개인정보 취급주의 색깔
	$wp_customize->add_setting('lotto|free_number|privacy_color',
		array(
			'default' => '#fff'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control($wp_customize, 'lotto|free_number|privacy_color',
			array(
				'label' => '개인정보 취급주의 색깔',
				'section' => 'lotto|free_number',
				'settings'=> 'lotto|free_number|privacy_color',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('lotto|free_number|privacy_color',
		array(
			'selector' => 'p.lotto_free_number_privacy_color',
			'settings' => 'lotto|free_number|privacy_color',
		)
	);
    
    // 로또 -> 무료번호받기 -> 전송버튼
	$wp_customize->add_setting('lotto|free_number|submit',
		array(
			'transport' => 'postMessage',
			'default' => '무료 번호 받기',
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control( $wp_customize, 'lotto|free_number|submit',
			array(
				'label' => '전송 버튼 텍스트',
				'type' => 'text',
				'section' => 'lotto|free_number',
				'settings'=> 'lotto|free_number|submit',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('lotto|free_number|submit',
		array(
			'selector' => 'p.lotto_free_number_submit',
			'settings' => 'lotto|free_number|submit',
			'render_callback' => function() {
				return get_theme_mod('lotto|free_number|submit');
			},
		)
	);
    
    // 로또 -> 무료번호받기 -> 전송버튼 색깔
	$wp_customize->add_setting('lotto|free_number|submit_color',
		array(
			'default' => '#fff',
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control( $wp_customize, 'lotto|free_number|submit_color',
			array(
				'label' => '전송버튼 색깔',
				'section' => 'lotto|free_number',
				'settings'=> 'lotto|free_number|submit_color',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('lotto|free_number|submit_color',
		array(
			'selector' => 'button.lotto_free_number_submit_color',
			'settings' => 'lotto|free_number|submit_color',
			'render_callback' => function() {
				return get_theme_mod('lotto|free_number|submit_color');
			},
		)
	);
    
    // 로또 -> 무료번호받기 -> 전송버튼 배경색깔
	$wp_customize->add_setting('lotto|free_number|submit_background_color',
		array(
			'default' => '#383838',
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control( $wp_customize, 'lotto|free_number|submit_background_color',
			array(
				'label' => '전송버튼 배경색깔',
				'section' => 'lotto|free_number',
				'settings'=> 'lotto|free_number|submit_background_color',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('lotto|free_number|submit_background_color',
		array(
			'selector' => 'button.lotto_free_number_submit_background_color',
			'settings' => 'lotto|free_number|submit_background_color',
			'render_callback' => function() {
				return get_theme_mod('lotto|free_number|submit_background_color');
			},
		)
	);
    
    // 로또 -> 무료번호받기 -> 배경색
	$wp_customize->add_setting('lotto|free_number|color',
		array(
			'default' => '#51b6d9',
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control( $wp_customize, 'lotto|free_number|color',
			array(
				'label' => '배경색',
				'section' => 'lotto|free_number',
				'settings'=> 'lotto|free_number|color',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('lotto|free_number|color',
		array(
			'selector' => 'section.lotto_free_number_color',
			'settings' => 'lotto|free_number|color',
			'render_callback' => function() {
				return get_theme_mod('lotto|free_number|color');
			},
		)
	);
	
	// 로또 -> 무료번호받기 -> API URL
	$wp_customize->add_setting('lotto|free_number|api_url',
		array(
			'default' => 'https://free.onedaynice.co.kr/complete.php?cmpny=lottoanalysis&to=b'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'lotto|free_number|api_url',
			array(
				'label' => 'API URL',
				'description' => '사용자 정보를 저장할 API URL을 입력해주세요',
				'type' => 'text',
				'section' => 'lotto|free_number',
				'settings'=> 'lotto|free_number|api_url',
			)
		)
	);
    
    // 로또 -> 무료번호받기 -> PADDING( 768 < WIDTH )
	$wp_customize->add_setting('lotto|free_number|padding_more_than_768',
		array(
			'transport' => 'postMessage',
			'default' => '80px'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'lotto|free_number|padding_more_than_768',
			array(
				'label' => 'PADDING [768 < WIDTH]',
				'type' => 'select',
				'section' => 'lotto|free_number',
				'settings'=> 'lotto|free_number|padding_more_than_768',
                'choices' => array(
                    '0px' => '0px', '10px' => '10px', '20px' => '20px', '30px' => '30px', '40px' => '40px', '50px' => '50px', '60px' => '60px', '70px' => '70px', '80px' => '80px', '90px' => '90px', '100px' => '100px', '110px' => '110px', '120px' => '120px',  '130px' => '130px', '140px' => '140px', '150px' => '150px', '160px' => '160px', '170px' => '170px', '180px' => '180px', '190px' => '190px', '200px' => '200px'
			     )
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('lotto|free_number|padding_more_than_768',
		array(
			'selector' => 'p.lotto_free_number_padding_more_than_768',
			'settings' => 'lotto|free_number|padding_more_than_768',
			'render_callback' => function() {
				return get_theme_mod('lotto|free_number|padding_more_than_768');
			},
		)
	);
    
    // 로또 -> 무료번호받기 -> PADDING( 0 < WIDTH < 768 )
	$wp_customize->add_setting('lotto|free_number|padding_more_than_0',
		array(
			'transport' => 'postMessage',
			'default' => '60px'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'lotto|free_number|padding_more_than_0',
			array(
				'label' => 'PADDING [0 < WIDTH < 768]',
				'type' => 'select',
				'section' => 'lotto|free_number',
				'settings'=> 'lotto|free_number|padding_more_than_0',
                'choices' => array(
                    '0px' => '0px', '10px' => '10px', '20px' => '20px', '30px' => '30px', '40px' => '40px', '50px' => '50px', '60px' => '60px', '70px' => '70px', '80px' => '80px', '90px' => '90px', '100px' => '100px', '110px' => '110px', '120px' => '120px',  '130px' => '130px', '140px' => '140px', '150px' => '150px', '160px' => '160px', '170px' => '170px', '180px' => '180px', '190px' => '190px', '200px' => '200px'
			     )
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('lotto|free_number|padding_more_than_0',
		array(
			'selector' => 'p.lotto_free_number_padding_more_than_0',
			'settings' => 'lotto|free_number|padding_more_than_0',
			'render_callback' => function() {
				return get_theme_mod('lotto|free_number|padding_more_than_0');
			},
		)
	);
		
}

add_action('customize_register', 'customize_register_lotto_free_number');


function after_setup_theme_lotto_free_number(){
    
	file_log(__FILE__, __LINE__, __FUNCTION__, 'begin ');
    
	function lotto_free_number_scripts(){
        wp_enqueue_style('lotto_free_number', get_stylesheet_directory_uri().'/style/css/lotto_free_number.css');
        wp_enqueue_script('lotto_free_number', get_stylesheet_directory_uri().'/js/lotto_free_number.js', array(), false, true);
	}
    
	add_action('wp_enqueue_scripts', 'lotto_free_number_scripts', 100);
	
	function lotto_free_number_action(){
        $cnt = did_action('zerif_after_header');
        if( $cnt == 1 ) {
            get_template_part('sections/lotto_free_number');
        }
	}
	
	add_action('zerif_after_header',  'lotto_free_number_action');
}

add_action('after_setup_theme', 'after_setup_theme_lotto_free_number');
