<?php

function customize_register_about_us_01($wp_customize){
	file_log(__FILE__, __LINE__, __FUNCTION__, 'begin ');
    
    // ABOUT US
    $wp_customize->add_panel('about_us',
        array(
            'title' => 'ABOUT US',
            'description' => 'ABOUT US 관련 설정을 합니다.',
        )
    );
    
    // ABOUT US -> ABOUT US 01
    $wp_customize->add_section('about_us|01',
        array(
            'title' => 'ABOUT US 01',
            'panel' => 'about_us',
            'priority' => 1
        )
    );
    
    // ABOUT US -> ABOUT US 01 -> 숨기기
	$wp_customize->add_setting('about_us|01|hide',
		array(
			'transport' => 'postMessage',
			'default' => false,
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'about_us|01|hide',
			array(
				'label' => '숨기기',
				'type' => 'checkbox',
				'section' => 'about_us|01',
				'settings'=> 'about_us|01|hide',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('about_us|01|hide',
		array(
			'selector' => 'div.about_us_01_hide',
			'settings' => 'about_us|01|hide',
			'render_callback' => function() {
				return get_theme_mod('about_us|01|hide');
			},
		)
	);
    
    // ABOUT US -> ABOUT US 01 -> 제목
	$wp_customize->add_setting('about_us|01|title',
		array(
			'transport' => 'postMessage',
			'default' => '로또코치 시스템소개'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'about_us|01|title',
			array(
				'label' => '제목',
				'type' => 'text',
				'section' => 'about_us|01',
				'settings'=> 'about_us|01|title',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('about_us|01|title',
		array(
			'selector' => 'h3.about_us_01_title',
			'settings' => 'about_us|01|title',
			'render_callback' => function() {
				return get_theme_mod('about_us|01|title');
			},
		)
	);
    
    // ABOUT US -> ABOUT US 01 -> 제목 색깔
	$wp_customize->add_setting('about_us|01|title_color',
		array(
			'default' => '#333'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control($wp_customize, 'about_us|01|title_color',
			array(
				'label' => '제목 색깔',
				'section' => 'about_us|01',
				'settings'=> 'about_us|01|title_color',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('about_us|01|title_color',
		array(
			'selector' => 'div.about_us_01_title_color',
			'settings' => 'about_us|01|title_color',
		)
	);
    
    // ABOUT US -> ABOUT US 01 -> 부제목
	$wp_customize->add_setting('about_us|01|sub_title',
		array(
			'transport' => 'postMessage',
			'default' => '로또코치의 시스템은 지난 로또 <em class="em_pointer">당첨번호</em>들의 <em class="em_pointer">통계</em>를 기반으로 합니다.'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'about_us|01|sub_title',
			array(
				'label' => '부제목',
                'description' => '강조가 필요한 곳에 em class="em_pointer" 태그를 삽입해주세요.',
				'type' => 'text',
				'section' => 'about_us|01',
				'settings'=> 'about_us|01|sub_title',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('about_us|01|sub_title',
		array(
			'selector' => 'h3.about_us_01_sub_title',
			'settings' => 'about_us|01|sub_title',
			'render_callback' => function() {
				return get_theme_mod('about_us|01|sub_title');
			},
		)
	);
    
    // ABOUT US -> ABOUT US 01 -> 부제목 색깔
	$wp_customize->add_setting('about_us|01|sub_title_color',
		array(
			'default' => '#333'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control($wp_customize, 'about_us|01|sub_title_color',
			array(
				'label' => '부제목 색깔',
				'section' => 'about_us|01',
				'settings'=> 'about_us|01|sub_title_color',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('about_us|01|sub_title_color',
		array(
			'selector' => 'div.about_us_01_sub_title_color',
			'settings' => 'about_us|01|sub_title_color',
		)
	);
    
    // ABOUT US -> ABOUT US 01 -> 부제목 강조 색깔
	$wp_customize->add_setting('about_us|01|sub_title_point_color',
		array(
			'default' => '#03a9f4'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control($wp_customize, 'about_us|01|sub_title_point_color',
			array(
				'label' => '부제목 강조 색깔',
				'section' => 'about_us|01',
				'settings'=> 'about_us|01|sub_title_point_color',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('about_us|01|sub_title_point_color',
		array(
			'selector' => 'div.about_us_01_sub_title_point_color',
			'settings' => 'about_us|01|sub_title_point_color',
		)
	);
    
    // ABOUT US -> ABOUT US 01 -> 내용
	$wp_customize->add_setting('about_us|01|content',
		array(
			'transport' => 'postMessage',
			'default' => '지난 번호들을 고급 통계시스템을 통해 회원들에게 제공됩니다. 이는 기존 로또 당첨번호를 토대로 당첨확률이 낮다고 판단되는 번호를 제외시키기 때문입니다. 이를 통해 로또1등, 로또2등 당첨 등의 고액 로또 당첨이 가능합니다.'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'about_us|01|content',
			array(
				'label' => '내용',
                'description' => '줄바꿈이 필요한 곳에 br 태그를 넣어주세요.',
				'type' => 'textarea',
				'section' => 'about_us|01',
				'settings'=> 'about_us|01|content',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('about_us|01|content',
		array(
			'selector' => 'p.about_us_01_content',
			'settings' => 'about_us|01|content',
			'render_callback' => function() {
				return get_theme_mod('about_us|01|content');
			},
		)
	);
    
    // ABOUT US -> ABOUT US 01 -> 내용 색깔
	$wp_customize->add_setting('about_us|01|content_color',
		array(
			'default' => '#25292a'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control($wp_customize, 'about_us|01|content_color',
			array(
				'label' => '내용 색깔',
				'section' => 'about_us|01',
				'settings'=> 'about_us|01|content_color',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('about_us|01|content_color',
		array(
			'selector' => 'p.about_us_01_content_color',
			'settings' => 'about_us|01|content_color',
		)
	);
    
    // ABOUT US -> ABOUT US 01 -> 버튼
	$wp_customize->add_setting('about_us|01|button',
		array(
			'transport' => 'postMessage',
			'default' => '무료번호받기'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'about_us|01|button',
			array(
				'label' => '버튼',
				'type' => 'text',
				'section' => 'about_us|01',
				'settings'=> 'about_us|01|button',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('about_us|01|button',
		array(
			'selector' => 'span.about_us_01_button',
			'settings' => 'about_us|01|button',
			'render_callback' => function() {
				return get_theme_mod('about_us|01|button');
			},
		)
	);
    
    // ABOUT US -> ABOUT US 01 -> 버튼 색깔
	$wp_customize->add_setting('about_us|01|button_color',
		array(
			'default' => '#fff'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control($wp_customize, 'about_us|01|button_color',
			array(
				'label' => '버튼 색깔',
				'section' => 'about_us|01',
				'settings'=> 'about_us|01|button_color',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('about_us|01|button_color',
		array(
			'selector' => 'a.about_us_01_button_color',
			'settings' => 'about_us|01|button_color',
			'render_callback' => function() {
				return get_theme_mod('about_us|01|button_color');
			},
		)
	);
    
    // ABOUT US -> ABOUT US 01 -> 버튼 배경색깔
	$wp_customize->add_setting('about_us|01|button_background',
		array(
			'default' => '#03a9f4'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control($wp_customize, 'about_us|01|button_background',
			array(
				'label' => '버튼 배경색깔',
				'section' => 'about_us|01',
				'settings'=> 'about_us|01|button_background',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('about_us|01|button_background',
		array(
			'selector' => 'a.about_us_01_button_background',
			'settings' => 'about_us|01|button_background',
			'render_callback' => function() {
				return get_theme_mod('about_us|01|button_background');
			},
		)
	);

    // ABOUT US -> ABOUT US 01 -> 이미지
	$wp_customize->add_setting('about_us|01|image',
		array(
			'transport' => 'postMessage',
			'default' => 'https://user-63680339-work.colibriwp.com/sample-project/wp-content/uploads/2021/01/colibri-image-320.png',
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Cropped_Image_Control($wp_customize, 'about_us|01|image',
			array(
				'label' => '이미지',
                'type' => 'image',
                'section' => 'about_us|01',
                'settings' => 'about_us|01|image'
			)
		)
	);
    $wp_customize->selective_refresh->add_partial('about_us|01|image',
		array(
			'selector' => 'img.about_us_01_image',
			'settings' => 'about_us|01|image',
			'render_callback' => function() {
				return get_theme_mod('about_us|01|image');
			},
		)
	);
    
    // ABOUT US -> ABOUT US 01 -> 이미지 테두리
	$wp_customize->add_setting('about_us|01|image_border',
		array(
			'default' => '#03a9f4'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control($wp_customize, 'about_us|01|image_border',
			array(
				'label' => '이미지 테두리',
				'section' => 'about_us|01',
				'settings'=> 'about_us|01|image_border',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('about_us|01|image_border',
		array(
			'selector' => 'div.about_us_01_image_border',
			'settings' => 'about_us|01|image_border',
			'render_callback' => function() {
				return get_theme_mod('about_us|01|image_border');
			},
		)
	);
    
    // ABOUT US -> ABOUT US 01 -> 배경 색깔
	$wp_customize->add_setting('about_us|01|background_color',
		array(
			'default' => '#F5FAFD'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control($wp_customize, 'about_us|01|background_color',
			array(
				'label' => '배경 색깔',
				'section' => 'about_us|01',
				'settings'=> 'about_us|01|background_color',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('about_us|01|background_color',
		array(
			'selector' => 'div.about_us_01_background_color',
			'settings' => 'about_us|01|background_color',
			'render_callback' => function() {
				return get_theme_mod('about_us|01|background_color');
			},
		)
	);
    
    // ABOUT US -> ABOUT US 01 -> PADDING( 1024 < WIDTH )
	$wp_customize->add_setting('about_us|01|padding_more_than_1024',
		array(
			'transport' => 'postMessage',
			'default' => '90px'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'about_us|01|padding_more_than_1024',
			array(
				'label' => 'PADDING [1024 < WIDTH]',
				'type' => 'select',
				'section' => 'about_us|01',
				'settings'=> 'about_us|01|padding_more_than_1024',
                'choices' => array(
                    '0px' => '0px', '10px' => '10px', '20px' => '20px', '30px' => '30px', '40px' => '40px', '50px' => '50px', '60px' => '60px', '70px' => '70px', '80px' => '80px', '90px' => '90px', '100px' => '100px', '110px' => '110px', '120px' => '120px',  '130px' => '130px', '140px' => '140px', '150px' => '150px', '160px' => '160px', '170px' => '170px', '180px' => '180px', '190px' => '190px', '200px' => '200px'
			     )
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('about_us|01|padding_more_than_1024',
		array(
			'selector' => 'p.about_us_01_padding_more_than_1024',
			'settings' => 'about_us|01|padding_more_than_1024',
			'render_callback' => function() {
				return get_theme_mod('about_us|01|padding_more_than_1024');
			},
		)
	);
    
    // ABOUT US -> ABOUT US 01 -> PADDING( 768 < WIDTH < 1024 )
	$wp_customize->add_setting('about_us|01|padding_more_than_768',
		array(
			'transport' => 'postMessage',
			'default' => '60px'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'about_us|01|padding_more_than_768',
			array(
				'label' => 'PADDING [768 < WIDTH < 1024]',
				'type' => 'select',
				'section' => 'about_us|01',
				'settings'=> 'about_us|01|padding_more_than_768',
                'choices' => array(
                    '0px' => '0px', '10px' => '10px', '20px' => '20px', '30px' => '30px', '40px' => '40px', '50px' => '50px', '60px' => '60px', '70px' => '70px', '80px' => '80px', '90px' => '90px', '100px' => '100px', '110px' => '110px', '120px' => '120px',  '130px' => '130px', '140px' => '140px', '150px' => '150px', '160px' => '160px', '170px' => '170px', '180px' => '180px', '190px' => '190px', '200px' => '200px'
			     )
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('about_us|01|padding_more_than_768',
		array(
			'selector' => 'p.about_us_01_padding_more_than_768',
			'settings' => 'about_us|01|padding_more_than_768',
			'render_callback' => function() {
				return get_theme_mod('about_us|01|padding_more_than_768');
			},
		)
	);
    
    // ABOUT US -> ABOUT US 01 -> PADDING( 0 < WIDTH < 768 )
	$wp_customize->add_setting('about_us|01|padding_more_than_0',
		array(
			'transport' => 'postMessage',
			'default' => '30px'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'about_us|01|padding_more_than_0',
			array(
				'label' => 'PADDING [0 < WIDTH < 768]',
				'type' => 'select',
				'section' => 'about_us|01',
				'settings'=> 'about_us|01|padding_more_than_0',
                'choices' => array(
                    '0px' => '0px', '10px' => '10px', '20px' => '20px', '30px' => '30px', '40px' => '40px', '50px' => '50px', '60px' => '60px', '70px' => '70px', '80px' => '80px', '90px' => '90px', '100px' => '100px', '110px' => '110px', '120px' => '120px',  '130px' => '130px', '140px' => '140px', '150px' => '150px', '160px' => '160px', '170px' => '170px', '180px' => '180px', '190px' => '190px', '200px' => '200px'
			     )
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('about_us|01|padding_more_than_0',
		array(
			'selector' => 'p.about_us_01_padding_more_than_0',
			'settings' => 'about_us|01|padding_more_than_0',
			'render_callback' => function() {
				return get_theme_mod('about_us|01|padding_more_than_0');
			},
		)
	);
    
}

add_action('customize_register', 'customize_register_about_us_01');


function after_setup_theme_about_us_01() {
	file_log(__FILE__, __LINE__, __FUNCTION__, 'begin ');
    
    function about_us_01_scripts(){
        wp_enqueue_style('about_us_01', get_stylesheet_directory_uri().'/temp_css/about_us_01.css');
	}
    
	add_action('wp_enqueue_scripts', 'about_us_01_scripts', 100);
	
	function about_us_01_action() {
        $cnt = did_action('zerif_after_header');
        if( $cnt == 1 ) {
            get_template_part('sections/about_us_01');
        }
	}
	
	add_action('zerif_after_header',  'about_us_01_action');
}

add_action('after_setup_theme', 'after_setup_theme_about_us_01');
