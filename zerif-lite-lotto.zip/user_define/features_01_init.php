<?php

function widgets_features_01(){
    file_log( __FILE__, __LINE__, __FUNCTION__, 'begin' );
    $id = 'sidebar_features_01';
    
    register_sidebar(
        array (
            'name'          => 'FEATURES 01',
            'id'            => $id,
            'before_widget' => '<p id="%1$s">',
            'after_widget'  => '</p>',
        )
    );
    is_active_sidebar($id);
}
add_action('widgets_init', 'widgets_features_01');


function user_define_register_widget_features_01(){
    register_widget('features_01_content_widget');
}
add_action('widgets_init', 'user_define_register_widget_features_01');


class features_01_content_widget extends WP_Widget {
    function __construct(){
        parent::__construct(
            'feature_01_content_widget',
            'FEATURE 01 CONTENT',
            array('description' => 'FEATURE 01 내용 위젯')

        );
        add_action( 'admin_enqueue_scripts', array( $this, 'widget_scripts' ) );
    }
    
    function update( $new_instance, $old_instance ) {
        $instance                        = $old_instance;
        $instance['text']                = $new_instance['text'];
        $instance['title']               = $new_instance['title'];
        $instance['title_color']         = $new_instance['title_color'];
        $instance['content_color']       = $new_instance['content_color'];
        $instance['image_uri']           = $new_instance['image_uri'];
        $instance['custom_media_id']     = $new_instance['custom_media_id'];
        $instance['image_in_customizer'] = $new_instance['image_in_customizer'];
        return $instance;

    }

    function widget($args, $instance){

        echo $args['before_widget'];

        ?>
        
        <div class="h-column h-column-container d-flex h-col-lg-4 h-col-md-6 h-col-12 style-614-outer style-local-5-c30-outer">
            <div data-colibri-id="5-c30" class="d-flex h-flex-basis h-column__inner h-px-lg-0 h-px-md-0 h-px-0 v-inner-lg-0 v-inner-md-0 v-inner-0 style-614 style-local-5-c30 position-relative">
                <div class="w-100 h-y-container h-column__content h-column__v-align flex-basis-100 align-self-lg-start align-self-md-start align-self-start">
                    <div data-colibri-id="5-c31" class="d-block style-615 style-local-5-c31 position-relative h-element">
                        <div class="h-image__frame-container-outer" style="text-align: center;">
                            <div class="h-image__frame-container">
                                <img src="<?php if( isset($instance['image_uri']) ){echo esc_url( $instance['image_uri'] );}?>" class="wp-image-827 style-615-image style-local-5-c31-image" alt="">
                                <div class="h-image__frame h-hide-lg h-hide-md h-hide-sm style-615-frameImage style-local-5-c31-frameImage"></div>
                            </div>
                        </div>
                    </div>
                    <div data-colibri-id="5-c32" class="h-row-container gutters-row-lg-0 gutters-row-md-0 gutters-row-2 gutters-row-v-lg-0 gutters-row-v-md-0 gutters-row-v-2 style-616 style-local-5-c32 position-relative">
                        <div class="h-row justify-content-lg-center justify-content-md-center justify-content-center align-items-lg-stretch align-items-md-stretch align-items-stretch gutters-col-lg-0 gutters-col-md-0 gutters-col-2 gutters-col-v-lg-0 gutters-col-v-md-0 gutters-col-v-2">
                            <div class="h-column h-column-container d-flex h-col-lg-auto h-col-md-auto h-col-auto style-617-outer style-local-5-c33-outer">
                                <div data-colibri-id="5-c33" class="d-flex h-flex-basis h-column__inner h-px-lg-2 h-px-md-3 h-px-2 v-inner-lg-2 v-inner-md-3 v-inner-2 style-617 style-local-5-c33 position-relative">
                                    <div class="w-100 h-y-container h-column__content h-column__v-align flex-basis-100 align-self-lg-start align-self-md-start align-self-start">
                                        <div data-colibri-id="5-c34" class="h-global-transition-all h-heading style-618 style-local-5-c34 position-relative h-element">
                                            <div class="h-heading__outer style-618 style-local-5-c34">
                                                <h4 class="" style="color: <?php if( isset($instance['title_color']) ){ echo $instance['title_color']; }?>"><?php if( isset($instance['title']) ){ echo $instance['title']; }?></h4>
                                            </div>
                                        </div>
                                        <div data-colibri-id="5-c35" class="h-text h-text-component style-619 style-local-5-c35 position-relative h-element">
                                            <div class="">
                                                <p style="color: <?php if( isset($instance['content_color']) ){ echo $instance['content_color']; }?>"><?php if( isset($instance['text']) ){ echo $instance['text']; }?></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div data-colibri-id="5-c36" class="h-x-container style-620 style-local-5-c36 position-relative h-element"></div>
                </div>
            </div>
        </div>

        <?php

        echo $args['after_widget'];

    }

    function form( $instance ) {
        ?>
        
        <p>
            <label class="customize-control-title">제목</label>
            <input type="text" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php if ( ! empty( $instance['title'] ) ): echo $instance['title']; endif; ?>" class="widefat">
        </p>
        <p>
            <label class="customize-control-title">제목 색깔</label>
            <input type="color" name="<?php echo $this->get_field_name( 'title_color' ); ?>" value="<?php if ( ! empty( $instance['title_color'] ) ): echo $instance['title_color']; endif; ?>" class="widefat content_color" style="width: 60px; height: 25px;">
        </p>
        <p>
            <label class="customize-control-title">내용</label>
            <textarea class="widefat" rows="4" cols="20" name="<?php echo $this->get_field_name( 'text' ); ?>"><?php if ( ! empty( $instance['text'] ) ): echo htmlspecialchars_decode( $instance['text'] ); endif; ?></textarea>
        </p>
        <p>
            <label class="customize-control-title">내용 색깔</label>
            <input type="color" name="<?php echo $this->get_field_name( 'content_color' ); ?>" value="<?php if ( ! empty( $instance['content_color'] ) ): echo $instance['content_color']; endif; ?>" class="widefat content_color" style="width: 60px; height: 25px;">
        </p>
        <p>
            <label class="customize-control-title">이미지</label>
            <?php
            $image_in_customizer = '';
            $display             = 'none';
            if ( ! empty( $instance['image_in_customizer'] ) && ! empty( $instance['image_uri'] ) ) {
                $image_in_customizer = esc_url( $instance['image_in_customizer'] );
                $display             = 'inline-block';
            } else {
                if ( ! empty( $instance['image_uri'] ) ) {
                    $image_in_customizer = esc_url( $instance['image_uri'] );
                    $display             = 'inline-block';
                }
            }
            $zerif_image_in_customizer = $this->get_field_name( 'image_in_customizer' );
            ?>
            <input type="hidden" class="custom_media_display_in_customizer"
                   name="<?php if ( ! empty( $zerif_image_in_customizer ) ) {
                       echo $zerif_image_in_customizer;
                   } ?>"
                   value="<?php if ( ! empty( $instance['image_in_customizer'] ) ): echo $instance['image_in_customizer']; endif; ?>">
            <img class="custom_media_image" src="<?php echo $image_in_customizer; ?>"
                 style="margin:0;padding:0;max-width:100px;float:left;display:<?php echo $display; ?>"
                 alt="<?php echo __( 'Uploaded image', 'zerif-lite' ); ?>"/>

            <input type="text" class="widefat custom_media_url"
                   name="<?php echo $this->get_field_name( 'image_uri' ); ?>"
                   value="<?php if ( ! empty( $instance['image_uri'] ) ): echo $instance['image_uri']; endif; ?>"
                   style="margin-top:5px;">

            <input type="button" class="button button-primary custom_media_button" id="custom_media_button"
                   name="<?php echo $this->get_field_name( 'image_uri' ); ?>"
                   value="<?php _e( 'Upload Image', 'zerif-lite' ); ?>" style="margin-top:5px;">
        </p>

        <input class="custom_media_id" id="<?php echo $this->get_field_id( 'custom_media_id' ); ?>"
               name="<?php echo $this->get_field_name( 'custom_media_id' ); ?>" type="hidden"
               value="<?php if ( ! empty( $instance["custom_media_id"] ) ): echo $instance["custom_media_id"]; endif; ?>"/>

        <?php

    }
    
    function widget_scripts( $hook ) {
        if ( $hook != 'widgets.php' ) {
            return;
        }
        wp_enqueue_media();
        wp_enqueue_script( 'zerif_widget_media_script', get_template_directory_uri() . '/js/widget-media.js', false, '1.1', true );
    }


}


function customize_register_features_01($wp_customize){
	file_log(__FILE__, __LINE__, __FUNCTION__, 'begin ');
    
    // FEATURES
    $wp_customize->add_panel('features',
        array(
            'title' => 'FEATURES',
            'description' => 'FEATURE 관련 설정을 합니다.',
        )
    );
    
    // FEATURES -> FEATURES 01
    $wp_customize->add_section('features|01',
        array(
            'title' => 'FEATURES 01',
            'panel' => 'features',
            'priority' => 1
        )
    );
    
    // FEATURES -> FEATURES 01 -> 숨기기
	$wp_customize->add_setting('features|01|hide',
		array(
			'transport' => 'postMessage',
			'default' => false,
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'features|01|hide',
			array(
				'label' => '숨기기',
				'type' => 'checkbox',
				'section' => 'features|01',
				'settings'=> 'features|01|hide',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('features|01|hide',
		array(
			'selector' => 'div.features_01_hide',
			'settings' => 'features|01|hide',
			'render_callback' => function() {
				return get_theme_mod('features|01|hide');
			},
		)
	);
    
    // FEATURES -> FEATURES 01 -> 제목
	$wp_customize->add_setting('features|01|title',
		array(
			'transport' => 'postMessage',
			'default' => '로또코치 자주하는 질문'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'features|01|title',
			array(
				'label' => '제목',
				'type' => 'text',
				'section' => 'features|01',
				'settings'=> 'features|01|title',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('features|01|title',
		array(
			'selector' => 'h2.features_01_title',
			'settings' => 'features|01|title',
			'render_callback' => function() {
				return get_theme_mod('features|01|title');
			},
		)
	);
    
    // FEATURES -> FEATURES 01 -> 제목 색깔
	$wp_customize->add_setting('features|01|title_color',
		array(
			'default' => '#474747'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control($wp_customize, 'features|01|title_color',
			array(
				'label' => '제목 색깔',
				'section' => 'features|01',
				'settings'=> 'features|01|title_color',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('features|01|title_color',
		array(
			'selector' => 'div.features_01_title_color',
			'settings' => 'features|01|title_color',
		)
	);
    
    // FEATURES -> FEATURES 01 -> 부제목
	$wp_customize->add_setting( 'features|01|sub_title',
		array(
			'transport' => 'postMessage',
			'default' => '이제 로또코치를 통해 로또 1등 당첨의 든든한 개인코치를 영입해 보세요.'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'features|01|sub_title',
			array(
				'label' => '부제목',
				'type' => 'text',
				'section' => 'features|01',
				'settings'=> 'features|01|sub_title',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('features|01|sub_title',
		array(
			'selector' => 'p.features_01_sub_title',
			'settings' => 'features|01|sub_title',
			'render_callback' => function() {
				return get_theme_mod('features|01|sub_title');
			},
		)
	);
    
    // FEATURES -> FEATURES 01 -> 부제목 색깔
	$wp_customize->add_setting('features|01|sub_title_color',
		array(
			'default' => '#474747'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control($wp_customize, 'features|01|sub_title_color',
			array(
				'label' => '부제목 색깔',
				'section' => 'features|01',
				'settings'=> 'features|01|sub_title_color',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('features|01|sub_title_color',
		array(
			'selector' => 'div.features_01_sub_title_color',
			'settings' => 'features|01|sub_title_color',
		)
	);
    
    // FEATURES -> FEATURES 01 -> 배경 색깔
	$wp_customize->add_setting('features|01|background_color',
		array(
			'default' => '#fff'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control($wp_customize, 'features|01|background_color',
			array(
				'label' => '배경 색깔',
				'section' => 'features|01',
				'settings'=> 'features|01|background_color',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('features|01|background_color',
		array(
			'selector' => 'div.features_01_background_color',
			'settings' => 'features|01|background_color',
		)
	);
    
    // FEATURES -> FEATURES 01 -> PADDING( 1024 < WIDTH )
	$wp_customize->add_setting('features|01|padding_more_than_1024',
		array(
			'transport' => 'postMessage',
			'default' => '90px'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'features|01|padding_more_than_1024',
			array(
				'label' => 'PADDING [1024 < WIDTH]',
				'type' => 'select',
				'section' => 'features|01',
				'settings'=> 'features|01|padding_more_than_1024',
                'choices' => array(
                    '0px' => '0px', '10px' => '10px', '20px' => '20px', '30px' => '30px', '40px' => '40px', '50px' => '50px', '60px' => '60px', '70px' => '70px', '80px' => '80px', '90px' => '90px', '100px' => '100px', '110px' => '110px', '120px' => '120px',  '130px' => '130px', '140px' => '140px', '150px' => '150px', '160px' => '160px', '170px' => '170px', '180px' => '180px', '190px' => '190px', '200px' => '200px'
			     )
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('features|01|padding_more_than_1024',
		array(
			'selector' => 'p.features_01_padding_more_than_1024',
			'settings' => 'features|01|padding_more_than_1024',
			'render_callback' => function() {
				return get_theme_mod('features|01|padding_more_than_1024');
			},
		)
	);
    
    // FEATURES -> FEATURES 01 -> PADDING( 768 < WIDTH < 1024 )
	$wp_customize->add_setting('features|01|padding_more_than_768',
		array(
			'transport' => 'postMessage',
			'default' => '60px'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'features|01|padding_more_than_768',
			array(
				'label' => 'PADDING [768 < WIDTH < 1024]',
				'type' => 'select',
				'section' => 'features|01',
				'settings'=> 'features|01|padding_more_than_768',
                'choices' => array(
                    '0px' => '0px', '10px' => '10px', '20px' => '20px', '30px' => '30px', '40px' => '40px', '50px' => '50px', '60px' => '60px', '70px' => '70px', '80px' => '80px', '90px' => '90px', '100px' => '100px', '110px' => '110px', '120px' => '120px',  '130px' => '130px', '140px' => '140px', '150px' => '150px', '160px' => '160px', '170px' => '170px', '180px' => '180px', '190px' => '190px', '200px' => '200px'
			     )
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('features|01|padding_more_than_768',
		array(
			'selector' => 'p.features_01_padding_more_than_768',
			'settings' => 'features|01|padding_more_than_768',
			'render_callback' => function() {
				return get_theme_mod('features|01|padding_more_than_768');
			},
		)
	);
    
    // FEATURES -> FEATURES 01 -> PADDING( 0 < WIDTH < 768 )
	$wp_customize->add_setting('features|01|padding_more_than_0',
		array(
			'transport' => 'postMessage',
			'default' => '30px'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'features|01|padding_more_than_0',
			array(
				'label' => 'PADDING [0 < WIDTH < 768]',
				'type' => 'select',
				'section' => 'features|01',
				'settings'=> 'features|01|padding_more_than_0',
                'choices' => array(
                    '0px' => '0px', '10px' => '10px', '20px' => '20px', '30px' => '30px', '40px' => '40px', '50px' => '50px', '60px' => '60px', '70px' => '70px', '80px' => '80px', '90px' => '90px', '100px' => '100px', '110px' => '110px', '120px' => '120px',  '130px' => '130px', '140px' => '140px', '150px' => '150px', '160px' => '160px', '170px' => '170px', '180px' => '180px', '190px' => '190px', '200px' => '200px'
			     )
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('features|01|padding_more_than_0',
		array(
			'selector' => 'p.features_01_padding_more_than_0',
			'settings' => 'features|01|padding_more_than_0',
			'render_callback' => function() {
				return get_theme_mod('features|01|padding_more_than_0');
			},
		)
	);
    
    // 위젯 추가
    $section_id = 'sidebar-widgets-sidebar_features_01';
    $widget_section = $wp_customize->get_section( $section_id );
    
    if(!empty($widget_section)) {
        
        // 패널
        $widget_section->panel                                        = 'features';
        $widget_section->title                                        = 'FEATURES 01';
        $widget_section->priority                                     = 1;
            
        // 숨기기
        $wp_customize->get_control( 'features|01|hide' )->section     = $section_id;
        $wp_customize->get_control( 'features|01|hide' )->priority    = -1;
        
        // 제목
        $wp_customize->get_control( 'features|01|title' )->section     = $section_id;
        $wp_customize->get_control( 'features|01|title' )->priority    = -1;
        
        // 제목 색깔
        $wp_customize->get_control( 'features|01|title_color' )->section     = $section_id;
        $wp_customize->get_control( 'features|01|title_color' )->priority    = -1;
        
        // 부제목
        $wp_customize->get_control( 'features|01|sub_title' )->section     = $section_id;
        $wp_customize->get_control( 'features|01|sub_title' )->priority    = -1;
        
        // 부제목 색깔
        $wp_customize->get_control( 'features|01|sub_title_color' )->section     = $section_id;
        $wp_customize->get_control( 'features|01|sub_title_color' )->priority    = -1;
        
        // 배경 색깔
        $wp_customize->get_control( 'features|01|background_color' )->section     = $section_id;
        $wp_customize->get_control( 'features|01|background_color' )->priority    = -1;
        
        // PADDING( 1024 < WIDTH )
        $wp_customize->get_control( 'features|01|padding_more_than_1024' )->section     = $section_id;
        $wp_customize->get_control( 'features|01|padding_more_than_1024' )->priority    = -1;
        
        // PADDING( 768 < WIDTH < 1024 )
        $wp_customize->get_control( 'features|01|padding_more_than_768' )->section     = $section_id;
        $wp_customize->get_control( 'features|01|padding_more_than_768' )->priority    = -1;
        
        // PADDING( 0 < WIDTH < 768 )
        $wp_customize->get_control( 'features|01|padding_more_than_0' )->section     = $section_id;
        $wp_customize->get_control( 'features|01|padding_more_than_0' )->priority    = -1;
    
    } 
    
}

add_action('customize_register', 'customize_register_features_01');


function after_setup_theme_features_01() {
	file_log(__FILE__, __LINE__, __FUNCTION__, 'begin ');
    
	function features_01_scripts(){
        wp_enqueue_style('theme', get_stylesheet_directory_uri().'/style/css/theme.css');
        wp_enqueue_style('colibri', get_stylesheet_directory_uri().'/style/css/colibri.css', array('theme'));
        wp_enqueue_script('features_01', get_stylesheet_directory_uri().'/js/feature_01.js', array(), false, true);
	}
    
	add_action('wp_enqueue_scripts', 'features_01_scripts', 100);
	
	function features_01_action() {
        $cnt = did_action('zerif_after_header');
        if( $cnt == 1 ) {
            get_template_part('sections/features_01');
        }
	}
	
	add_action('zerif_after_header',  'features_01_action');
}

add_action('after_setup_theme', 'after_setup_theme_features_01');
