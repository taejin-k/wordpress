<?php

function widgets_text_box_02() {
	file_log( __FILE__, __LINE__, __FUNCTION__, 'begin' );
    $id = 'sidebar_text_box_02';

    register_sidebar(
        array(
            'name'          => 'TEXT BOX 02',
            'id'            => $id,
        	'before_widget' => '<p id="%1$s">',
            'after_widget'  => '</p>',
        )
    );
    is_active_sidebar($id);
}
add_action('widgets_init', 'widgets_text_box_02');


function user_define_register_widget_text_box_02(){
    register_widget('text_box_02_content_widget');
}
add_action('widgets_init', 'user_define_register_widget_text_box_02');


class text_box_02_content_widget extends WP_Widget{
    function __construct(){
        parent::__construct(
            'text_box_02_content_widget',
            'TEXT BOX 02 CONTENT',
            array('description' => 'TEXT BOX 02 내용 위젯')
        );
    }

    public function widget($args, $instance){
        
        echo $args['before_widget'];
        
        ?>

        <p class="text" style="color:<?php echo get_theme_mod('text_box|02|content_color', '#333'); ?>"><?php if( isset($instance['text']) ){ echo $instance['text']; }?></p>
        
        <?php

        echo $args['after_widget'];
    }
    
    public function form($instance){
        
        ?>
        <p>
            <label class="customize-control-title">내용</label>
            <span class="description customize-control-description">줄바꿈이 필요한 곳에 br태그를 삽입해주세요.</span>
            <textarea class="widefat" rows="4" cols="20" name="<?php echo $this->get_field_name( 'text' ); ?>"><?php if ( ! empty( $instance['text'] ) ): echo htmlspecialchars_decode( $instance['text'] ); endif; ?></textarea>
        </p>
        <?php
    }
    
    public function update($new_instance, $old_instance){
        $instance                        = $old_instance;
        $instance['text']                = $new_instance['text'];
        return $instance;
    }
}


function customize_register_text_box_02($wp_customize){
	file_log(__FILE__, __LINE__, __FUNCTION__, 'begin ');

    // TEXT BOX -> TEXT BOX 02
    $wp_customize->add_section('text_box|02',
        array(
            'title' => 'TEXT BOX 02',
        )
    );
    
    // TEXT BOX -> TEXT BOX 02 -> 숨기기
	$wp_customize->add_setting('text_box|02|hide',
		array(
			'transport' => 'postMessage',
			'default' => false,
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'text_box|02|hide',
			array(
				'label' => '숨기기',
				'type' => 'checkbox',
				'section' => 'text_box|02',
				'settings'=> 'text_box|02|hide',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('text_box|02|hide',
		array(
			'selector' => 'section.text_box_02_hide',
			'settings' => 'text_box|02|hide',
			'render_callback' => function() {
				return get_theme_mod('text_box|02|hide');
			},
		)
	);
    
    // TEXT BOX -> TEXT BOX 02 -> 제목
	$wp_customize->add_setting('text_box|02|title',
		array(
			'transport' => 'postMessage',
			'default' => '<span class="text_box_02_span_pointer">위젯</span>을 사용해 내용을 추가하세요.'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'text_box|02|title',
			array(
				'label' => '제목',
                'description' => '강조가 필요한 곳에 span class="text_box_02_span_pointer" 태그로 감싸주세요.',
				'type' => 'text',
				'section' => 'text_box|02',
				'settings'=> 'text_box|02|title',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('text_box|02|title',
		array(
			'selector' => 'p.text_box_02_title',
			'settings' => 'text_box|02|title',
			'render_callback' => function() {
				return get_theme_mod('text_box|02|title');
			},
		)
	);
    
    // TEXT BOX -> TEXT BOX 02 -> 제목 색깔
	$wp_customize->add_setting('text_box|02|title_color',
		array(
			'default' => '#474747'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control($wp_customize, 'text_box|02|title_color',
			array(
				'label' => '제목 색깔',
				'section' => 'text_box|02',
				'settings'=> 'text_box|02|title_color',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('text_box|02|title_color',
		array(
			'selector' => 'p.text_box_02_title_color',
			'settings' => 'text_box|02|title_color',
		)
	);
    
    // TEXT BOX -> TEXT BOX 02 -> 제목 강조 색깔
	$wp_customize->add_setting('text_box|02|title_point_color',
		array(
			'default' => '#474747'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control($wp_customize, 'text_box|02|title_point_color',
			array(
				'label' => '제목 강조 색깔',
				'section' => 'text_box|02',
				'settings'=> 'text_box|02|title_point_color',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('text_box|02|title_point_color',
		array(
			'selector' => 'span.text_box_02_title_point_color',
			'settings' => 'text_box|02|title_point_color',
		)
	);
    
    // TEXT BOX -> TEXT BOX 02 -> 부제목
	$wp_customize->add_setting('text_box|02|sub_title',
		array(
			'transport' => 'postMessage',
			'default' => '이제 AI시스템을 통해 향상된 <span class="text_box_02_sub_span_pointer">로또번호</span>를 무료로 사용해보세요.'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'text_box|02|sub_title',
			array(
				'label' => '부제목',
                'description' => '강조가 필요한 곳에 span class="text_box_02_sub_span_pointer" 태그로 감싸주세요.',
				'type' => 'text',
				'section' => 'text_box|02',
				'settings'=> 'text_box|02|sub_title',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('text_box|02|sub_title',
		array(
			'selector' => 'p.text_box_02_sub_title',
			'settings' => 'text_box|02|sub_title',
			'render_callback' => function() {
				return get_theme_mod('text_box|02|sub_title');
			},
		)
	);
    
    
    // TEXT BOX -> TEXT BOX 02 -> 부제목 색깔
	$wp_customize->add_setting('text_box|02|sub_title_color',
		array(
			'default' => '#3cadd4'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control($wp_customize, 'text_box|02|sub_title_color',
			array(
				'label' => '부제목 색깔',
				'section' => 'text_box|02',
				'settings'=> 'text_box|02|sub_title_color',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('text_box|02|sub_title_color',
		array(
			'selector' => 'p.text_box_02_sub_title_color',
			'settings' => 'text_box|02|sub_title_color',
		)
	);
    
    // TEXT BOX -> TEXT BOX 02 -> 부제목 강조 색깔
	$wp_customize->add_setting('text_box|02|sub_title_point_color',
		array(
			'default' => '#474747'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control($wp_customize, 'text_box|02|sub_title_point_color',
			array(
				'label' => '부제목 강조 색깔',
				'section' => 'text_box|02',
				'settings'=> 'text_box|02|sub_title_point_color',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('text_box|02|sub_title_point_color',
		array(
			'selector' => 'span.text_box_02_sub_title_point_color',
			'settings' => 'text_box|02|sub_title_point_color',
		)
	);
    
    // TEXT BOX -> TEXT BOX 02 -> 내용 색깔
	$wp_customize->add_setting('text_box|02|content_color',
		array(
			'default' => '#333'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control($wp_customize, 'text_box|02|content_color',
			array(
				'label' => '내용 색깔',
				'section' => 'text_box|02',
				'settings'=> 'text_box|02|content_color',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('text_box|02|content_color',
		array(
			'selector' => 'p.text_box_02_content_color',
			'settings' => 'text_box|02|content_color',
		)
	);
    
    // TEXT BOX -> TEXT BOX 02 -> 배경 색깔
	$wp_customize->add_setting('text_box|02|color',
		array(
			'default' => '#fff',
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control( $wp_customize, 'text_box|02|color',
			array(
				'label' => '배경색',
				'section' => 'text_box|02',
				'settings'=> 'text_box|02|color',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('text_box|02|color',
		array(
			'selector' => 'section.text_box_02_color',
			'settings' => 'text_box|02|color',
			'render_callback' => function() {
				return get_theme_mod('text_box|02|color');
			},
		)
	);
    
    // TEXT BOX -> TEXT BOX 02 -> 이미지
	$wp_customize->add_setting('text_box|02|image',
		array(
			'transport' => 'postMessage',
			'default' => 'http://192.168.0.75/wordpress/wp-content/themes/zerif-lite-lotto/img/text_box_02_image.jpg',
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Cropped_Image_Control($wp_customize, 'text_box|02|image',
			array(
				'label' => '이미지',
                'type' => 'image',
                'section' => 'text_box|02',
                'settings' => 'text_box|02|image'
			)
		)
	);
    $wp_customize->selective_refresh->add_partial('text_box|02|image',
		array(
			'selector' => 'div.text_box_02_image',
			'settings' => 'text_box|02|image',
			'render_callback' => function() {
				return get_theme_mod('text_box|02|image');
			},
		)
	);
    
    // TEXT BOX -> TEXT BOX 02 -> PADDING( 768 < WIDTH )
	$wp_customize->add_setting('lotto|winner_number|padding_more_than_768',
		array(
			'transport' => 'postMessage',
			'default' => '80px'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'lotto|winner_number|padding_more_than_768',
			array(
				'label' => 'PADDING [768 < WIDTH]',
				'type' => 'select',
				'section' => 'lotto|winner_number',
				'settings'=> 'lotto|winner_number|padding_more_than_768',
                'choices' => array(
                    '0px' => '0px', '10px' => '10px', '20px' => '20px', '30px' => '30px', '40px' => '40px', '50px' => '50px', '60px' => '60px', '70px' => '70px', '80px' => '80px', '90px' => '90px', '100px' => '100px', '110px' => '110px', '120px' => '120px',  '130px' => '130px', '140px' => '140px', '150px' => '150px', '160px' => '160px', '170px' => '170px', '180px' => '180px', '190px' => '190px', '200px' => '200px'
			     )
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('lotto|winner_number|padding_more_than_768',
		array(
			'selector' => 'p.lotto_winner_number_padding_more_than_768',
			'settings' => 'lotto|winner_number|padding_more_than_768',
			'render_callback' => function() {
				return get_theme_mod('lotto|winner_number|padding_more_than_768');
			},
		)
	);
    
    // TEXT BOX -> TEXT BOX 02 -> PADDING( 480 < WIDTH < 768 )
	$wp_customize->add_setting('lotto|winner_number|padding_more_than_480',
		array(
			'transport' => 'postMessage',
			'default' => '60px'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'lotto|winner_number|padding_more_than_480',
			array(
				'label' => 'PADDING [480 < WIDTH < 768]',
				'type' => 'select',
				'section' => 'lotto|winner_number',
				'settings'=> 'lotto|winner_number|padding_more_than_480',
                'choices' => array(
                    '0px' => '0px', '10px' => '10px', '20px' => '20px', '30px' => '30px', '40px' => '40px', '50px' => '50px', '60px' => '60px', '70px' => '70px', '80px' => '80px', '90px' => '90px', '100px' => '100px', '110px' => '110px', '120px' => '120px',  '130px' => '130px', '140px' => '140px', '150px' => '150px', '160px' => '160px', '170px' => '170px', '180px' => '180px', '190px' => '190px', '200px' => '200px'
			     )
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('lotto|winner_number|padding_more_than_480',
		array(
			'selector' => 'p.lotto_winner_number_padding_more_than_480',
			'settings' => 'lotto|winner_number|padding_more_than_480',
			'render_callback' => function() {
				return get_theme_mod('lotto|winner_number|padding_more_than_480');
			},
		)
	);
    
    // TEXT BOX -> TEXT BOX 02 -> PADDING( 0 < WIDTH < 480 )
	$wp_customize->add_setting('lotto|winner_number|padding_more_than_0',
		array(
			'transport' => 'postMessage',
			'default' => '40px'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'lotto|winner_number|padding_more_than_0',
			array(
				'label' => 'PADDING [0 < WIDTH < 480]',
				'type' => 'select',
				'section' => 'lotto|winner_number',
				'settings'=> 'lotto|winner_number|padding_more_than_0',
                'choices' => array(
                    '0px' => '0px', '10px' => '10px', '20px' => '20px', '30px' => '30px', '40px' => '40px', '50px' => '50px', '60px' => '60px', '70px' => '70px', '80px' => '80px', '90px' => '90px', '100px' => '100px', '110px' => '110px', '120px' => '120px',  '130px' => '130px', '140px' => '140px', '150px' => '150px', '160px' => '160px', '170px' => '170px', '180px' => '180px', '190px' => '190px', '200px' => '200px'
			     )
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('lotto|winner_number|padding_more_than_0',
		array(
			'selector' => 'p.lotto_winner_number_padding_more_than_0',
			'settings' => 'lotto|winner_number|padding_more_than_0',
			'render_callback' => function() {
				return get_theme_mod('lotto|winner_number|padding_more_than_0');
			},
		)
	);

    // 위젯 추가
    $section_id = 'sidebar-widgets-sidebar_text_box_02';
    $widget_section = $wp_customize->get_section( $section_id );
    
    if(!empty($widget_section)) {
        
        // 패널
        $widget_section->panel                                        = 'text_box';
        $widget_section->title                                        = 'TEXT BOX 02';
        $widget_section->priority                                     = 2;
            
        // 숨기기
        $wp_customize->get_control( 'text_box|02|hide' )->section     = $section_id;
        $wp_customize->get_control( 'text_box|02|hide' )->priority    = -1;
        
        // 제목 01
        $wp_customize->get_control( 'text_box|02|title' )->section     = $section_id;
        $wp_customize->get_control( 'text_box|02|title' )->priority    = -1;
        
        // 제목 색깔
        $wp_customize->get_control( 'text_box|02|title_color' )->section     = $section_id;
        $wp_customize->get_control( 'text_box|02|title_color' )->priority    = -1;
        
        // 제목 강조 색깔
        $wp_customize->get_control( 'text_box|02|title_point_color' )->section     = $section_id;
        $wp_customize->get_control( 'text_box|02|title_point_color' )->priority    = -1;
        
        // 부제목 색깔
        $wp_customize->get_control( 'text_box|02|sub_title' )->section     = $section_id;
        $wp_customize->get_control( 'text_box|02|sub_title' )->priority    = -1;
        
        // 부제목 색깔
        $wp_customize->get_control( 'text_box|02|sub_title_color' )->section     = $section_id;
        $wp_customize->get_control( 'text_box|02|sub_title_color' )->priority    = -1;
        
        // 부제목 강조 색깔
        $wp_customize->get_control( 'text_box|02|sub_title_point_color' )->section     = $section_id;
        $wp_customize->get_control( 'text_box|02|sub_title_point_color' )->priority    = -1;
        
        // 내용 색깔
        $wp_customize->get_control( 'text_box|02|content_color' )->section     = $section_id;
        $wp_customize->get_control( 'text_box|02|content_color' )->priority    = -1;
        
        // 배경 색깔
        $wp_customize->get_control( 'text_box|02|color' )->section     = $section_id;
        $wp_customize->get_control( 'text_box|02|color' )->priority    = -1;
        
        // 이미지
        $wp_customize->get_control( 'text_box|02|image' )->section     = $section_id;
        $wp_customize->get_control( 'text_box|02|image' )->priority    = -1;
        
        // PADDING( 768 < WIDTH )
        $wp_customize->get_control( 'lotto|winner_number|padding_more_than_768' )->section     = $section_id;
        $wp_customize->get_control( 'lotto|winner_number|padding_more_than_768' )->priority    = -1;
        
        // PADDING( 480 < WIDTH < 768 )
        $wp_customize->get_control( 'lotto|winner_number|padding_more_than_480' )->section     = $section_id;
        $wp_customize->get_control( 'lotto|winner_number|padding_more_than_480' )->priority    = -1;
        
        // PADDING( 0 < WIDTH < 480 )
        $wp_customize->get_control( 'lotto|winner_number|padding_more_than_0' )->section     = $section_id;
        $wp_customize->get_control( 'lotto|winner_number|padding_more_than_0' )->priority    = -1;
    
    }
    
}

add_action('customize_register', 'customize_register_text_box_02');


function after_setup_theme_text_box_02() {
	file_log(__FILE__, __LINE__, __FUNCTION__, 'begin ');
    
	function text_box_02_scripts(){
        wp_enqueue_style('text_box_02', get_stylesheet_directory_uri().'/style/css/text_box_02.css');
	}
    
	add_action('wp_enqueue_scripts', 'text_box_02_scripts', 100);
	
	function text_box_02_action() {
        $cnt = did_action('zerif_after_header');
        if( $cnt == 1 ) {
            get_template_part('sections/text_box_02');
        }
	}
	
	add_action('zerif_after_header',  'text_box_02_action');
}

add_action('after_setup_theme', 'after_setup_theme_text_box_02');
