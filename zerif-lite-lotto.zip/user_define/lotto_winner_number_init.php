<?php

function customize_register_lotto_winner_number($wp_customize){
	file_log(__FILE__, __LINE__, __FUNCTION__, 'begin ');
    
    // 로또
    $wp_customize->add_panel('lotto',
        array(
            'title' => 'LOTTO',
            'description' => '로또 관련 설정을 합니다.',
        )
    );

    // 로또 -> 로또당첨번호
    $wp_customize->add_section('lotto|winner_number',
        array(
            'title' => '로또당첨번호',
            'description' => '로또당첨번호를 확인합니다.',
            'panel' => 'lotto',
        )
    );
    
    // 로또 -> 로또당첨번호 -> 숨기기
	$wp_customize->add_setting('lotto|winner_number|hide',
		array(
			'transport' => 'postMessage',
			'default' => false,
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'lotto|winner_number|hide',
			array(
				'label' => '숨기기',
				'type' => 'checkbox',
				'section' => 'lotto|winner_number',
				'settings'=> 'lotto|winner_number|hide',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('lotto|winner_number|hide',
		array(
			'selector' => 'section.lotto_winner_number_hide',
			'settings' => 'lotto|winner_number|hide',
			'render_callback' => function() {
				return get_theme_mod('lotto|winner_number|hide');
			},
		)
	);
    
    // 로또 -> 로또당첨번호 -> 글자 색깔
	$wp_customize->add_setting('lotto|winner_number|text_color',
		array(
			'default' => '#474747',
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control( $wp_customize, 'lotto|winner_number|text_color',
			array(
				'label' => '글자 색깔',
				'section' => 'lotto|winner_number',
				'settings'=> 'lotto|winner_number|text_color',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('lotto|winner_number|text_color',
		array(
			'selector' => 'div.lotto_winner_number_text_color',
			'settings' => 'lotto|winner_number|text_color',
			'render_callback' => function() {
				return get_theme_mod('lotto|winner_number|text_color');
			},
		)
	);
    
    // 로또 -> 로또당첨번호 -> 회차 색깔
	$wp_customize->add_setting('lotto|winner_number|number_color',
		array(
			'default' => '#d5230f',
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control( $wp_customize, 'lotto|winner_number|number_color',
			array(
				'label' => '회차 색깔',
				'section' => 'lotto|winner_number',
				'settings'=> 'lotto|winner_number|number_color',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('lotto|winner_number|number_color',
		array(
			'selector' => 'span.lotto_winner_number_number_color',
			'settings' => 'lotto|winner_number|number_color',
			'render_callback' => function() {
				return get_theme_mod('lotto|winner_number|text_point_color');
			},
		)
	);
    
    // 로또 -> 로또당첨번호 -> 글자 강조 색깔
	$wp_customize->add_setting('lotto|winner_number|text_point_color',
		array(
			'default' => '#e64135',
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control( $wp_customize, 'lotto|winner_number|text_point_color',
			array(
				'label' => '글자 강조 색깔',
				'section' => 'lotto|winner_number',
				'settings'=> 'lotto|winner_number|text_point_color',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('lotto|winner_number|text_point_color',
		array(
			'selector' => 'span.lotto_winner_number_text_point_color',
			'settings' => 'lotto|winner_number|text_point_color',
			'render_callback' => function() {
				return get_theme_mod('lotto|winner_number|text_point_color');
			},
		)
	);
    
    // 로또 -> 로또당첨번호 -> 배경색
	$wp_customize->add_setting('lotto|winner_number|color',
		array(
			'default' => '#f5f5f5',
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control( $wp_customize, 'lotto|winner_number|color',
			array(
				'label' => '배경색',
				'section' => 'lotto|winner_number',
				'settings'=> 'lotto|winner_number|color',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('lotto|winner_number|color',
		array(
			'selector' => 'section.lotto_winner_number_color',
			'settings' => 'lotto|winner_number|color',
			'render_callback' => function() {
				return get_theme_mod('lotto|winner_number|color');
			},
		)
	);
    
    // 로또 -> 로또당첨번호 -> PADDING( 1024 < WIDTH )
	$wp_customize->add_setting('lotto|winner_number|padding_more_than_1024',
		array(
			'transport' => 'postMessage',
			'default' => '100px'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'lotto|winner_number|padding_more_than_1024',
			array(
				'label' => 'PADDING [1024 < WIDTH]',
				'type' => 'select',
				'section' => 'lotto|winner_number',
				'settings'=> 'lotto|winner_number|padding_more_than_1024',
                'choices' => array(
                    '0px' => '0px', '10px' => '10px', '20px' => '20px', '30px' => '30px', '40px' => '40px', '50px' => '50px', '60px' => '60px', '70px' => '70px', '80px' => '80px', '90px' => '90px', '100px' => '100px', '110px' => '110px', '120px' => '120px',  '130px' => '130px', '140px' => '140px', '150px' => '150px', '160px' => '160px', '170px' => '170px', '180px' => '180px', '190px' => '190px', '200px' => '200px'
			     )
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('lotto|winner_number|padding_more_than_1024',
		array(
			'selector' => 'p.lotto_winner_number_padding_more_than_1024',
			'settings' => 'lotto|winner_number|padding_more_than_1024',
			'render_callback' => function() {
				return get_theme_mod('lotto|winner_number|padding_more_than_1024');
			},
		)
	);
    
    // 로또 -> 로또당첨번호 -> PADDING( 640 < WIDTH < 1024 )
	$wp_customize->add_setting('lotto|winner_number|padding_more_than_640',
		array(
			'transport' => 'postMessage',
			'default' => '80px'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'lotto|winner_number|padding_more_than_640',
			array(
				'label' => 'PADDING [640 < WIDTH < 1024]',
				'type' => 'select',
				'section' => 'lotto|winner_number',
				'settings'=> 'lotto|winner_number|padding_more_than_640',
                'choices' => array(
                    '0px' => '0px', '10px' => '10px', '20px' => '20px', '30px' => '30px', '40px' => '40px', '50px' => '50px', '60px' => '60px', '70px' => '70px', '80px' => '80px', '90px' => '90px', '100px' => '100px', '110px' => '110px', '120px' => '120px',  '130px' => '130px', '140px' => '140px', '150px' => '150px', '160px' => '160px', '170px' => '170px', '180px' => '180px', '190px' => '190px', '200px' => '200px'
			     )
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('lotto|winner_number|padding_more_than_640',
		array(
			'selector' => 'p.lotto_winner_number_padding_more_than_640',
			'settings' => 'lotto|winner_number|padding_more_than_640',
			'render_callback' => function() {
				return get_theme_mod('lotto|winner_number|padding_more_than_640');
			},
		)
	);
    
    // 로또 -> 로또당첨번호 -> PADDING( 480 < WIDTH < 640 )
	$wp_customize->add_setting('lotto|winner_number|padding_more_than_480',
		array(
			'transport' => 'postMessage',
			'default' => '60px'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'lotto|winner_number|padding_more_than_480',
			array(
				'label' => 'PADDING [480 < WIDTH < 640]',
				'type' => 'select',
				'section' => 'lotto|winner_number',
				'settings'=> 'lotto|winner_number|padding_more_than_480',
                'choices' => array(
                    '0px' => '0px', '10px' => '10px', '20px' => '20px', '30px' => '30px', '40px' => '40px', '50px' => '50px', '60px' => '60px', '70px' => '70px', '80px' => '80px', '90px' => '90px', '100px' => '100px', '110px' => '110px', '120px' => '120px',  '130px' => '130px', '140px' => '140px', '150px' => '150px', '160px' => '160px', '170px' => '170px', '180px' => '180px', '190px' => '190px', '200px' => '200px'
			     )
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('lotto|winner_number|padding_more_than_480',
		array(
			'selector' => 'p.lotto_winner_number_padding_more_than_480',
			'settings' => 'lotto|winner_number|padding_more_than_480',
			'render_callback' => function() {
				return get_theme_mod('lotto|winner_number|padding_more_than_480');
			},
		)
	);
    
    // 로또 -> 로또당첨번호 -> PADDING( 0 < WIDTH < 480 )
	$wp_customize->add_setting('lotto|winner_number|padding_more_than_0',
		array(
			'transport' => 'postMessage',
			'default' => '40px'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'lotto|winner_number|padding_more_than_0',
			array(
				'label' => 'PADDING [0 < WIDTH < 480]',
				'type' => 'select',
				'section' => 'lotto|winner_number',
				'settings'=> 'lotto|winner_number|padding_more_than_0',
                'choices' => array(
                    '0px' => '0px', '10px' => '10px', '20px' => '20px', '30px' => '30px', '40px' => '40px', '50px' => '50px', '60px' => '60px', '70px' => '70px', '80px' => '80px', '90px' => '90px', '100px' => '100px', '110px' => '110px', '120px' => '120px',  '130px' => '130px', '140px' => '140px', '150px' => '150px', '160px' => '160px', '170px' => '170px', '180px' => '180px', '190px' => '190px', '200px' => '200px'
			     )
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('lotto|winner_number|padding_more_than_0',
		array(
			'selector' => 'p.lotto_winner_number_padding_more_than_0',
			'settings' => 'lotto|winner_number|padding_more_than_0',
			'render_callback' => function() {
				return get_theme_mod('lotto|winner_number|padding_more_than_0');
			},
		)
	);
    
    // 로또 -> 로또당첨번호 -> API URL
    $wp_customize->add_setting( 'lotto|winner_number|api_url',
        array(
            'default' => 'https://lottoblue.co.kr/json/module_lotto.php'
        )
    );
    $wp_customize->add_control(
        new WP_Customize_Control($wp_customize, 'lotto|winner_number|api_url',
            array(
                'label' => 'API URL',
                'description' => '로또당첨번호를 가져올 API URL을 입력해주세요',
                'type' => 'text',
                'section' => 'lotto|winner_number',
                'settings'=> 'lotto|winner_number|api_url',
            )
        )
    );
    
}

add_action('customize_register', 'customize_register_lotto_winner_number');


function after_setup_theme_lotto_winner_number() {
	file_log(__FILE__, __LINE__, __FUNCTION__, 'begin ');
    
	function lotto_winner_number_scripts(){
        wp_enqueue_style('lotto_winner_number', get_stylesheet_directory_uri().'/style/css/lotto_winner_number.css');
        wp_enqueue_script('lotto_winner_number', get_stylesheet_directory_uri().'/js/lotto_winner_number.js', array(), false, true);
	}
    
	add_action('wp_enqueue_scripts', 'lotto_winner_number_scripts', 100);
	
	function lotto_winner_number_action() {
        $cnt = did_action('zerif_after_header');
        if( $cnt == 1 ) {
            get_template_part('sections/lotto_winner_number');
        }
	}
	
	add_action('zerif_after_header',  'lotto_winner_number_action');
}

add_action('after_setup_theme', 'after_setup_theme_lotto_winner_number');
