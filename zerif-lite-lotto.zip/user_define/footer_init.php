<?php

function customize_register_footer($wp_customize){
	file_log(__FILE__, __LINE__, __FUNCTION__, 'begin ');
    
    // FOOTER
	$wp_customize->add_section('footer',
		array(
			'title' => 'FOOTER',
			'description' => 'FOOTER 관련 설정을 합니다.',
		)
	);
    
    // FOOTER -> 숨기기
	$wp_customize->add_setting('footer|hide',
		array(
			'transport' => 'postMessage',
			'default' => false,
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'footer|hide',
			array(
				'label' => '숨기기',
				'type' => 'checkbox',
				'section' => 'footer',
				'settings'=> 'footer|hide',
			)
		)
	);
    $wp_customize->selective_refresh->add_partial('footer|hide',
		array(
			'selector' => 'section.footer_hide',
			'settings' => 'footer|hide',
			'render_callback' => function() {
				return get_theme_mod('footer|hide');
			},
		)
	);

	// FOOTER -> 내용
	$wp_customize->add_setting('footer|text',
		array(
			'transport' => 'postMessage',
			'default' => '&copy; copyright by LottoCoach<br>상호명: 로또코치 &nbsp; 이메일: lottocoachhelp&copy;gmail.com'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'footer|text',
			array(
				'label' => '내용',
                'description' => '줄바꿈이 필요한 곳에 br태그를 삽입해주세요.<br>한 줄에 42글자를 넘기지 마세요.',
				'type' => 'textarea',
				'section' => 'footer',
				'settings'=> 'footer|text',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('footer|text',
		array(
			'selector' => 'p.footer_text',
			'settings' => 'footer|text',
			'render_callback' => function() {
				return get_theme_mod('footer|text');
			},
		)
	);
    
    // FOOTER -> 내용 색깔
	$wp_customize->add_setting('footer|text_color',
		array(
			'default' => '#fff'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control($wp_customize, 'footer|text_color',
			array(
				'label' => '내용 색깔',
				'section' => 'footer',
				'settings'=> 'footer|text_color',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('footer|text_color',
		array(
			'selector' => 'p.footer_text_color',
			'settings' => 'footer|text_color',
		)
	);
    
    // FOOTER -> 배경 색깔
	$wp_customize->add_setting('footer|background_color',
		array(
			'default' => '#383b43'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control($wp_customize, 'footer|background_color',
			array(
				'label' => '배경 색깔',
				'section' => 'footer',
				'settings'=> 'footer|background_color',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('footer|background_color',
		array(
			'selector' => 'section.footer_background_color',
			'settings' => 'footer|background_color',
		)
	);
    
    // FOOTER -> PADDING
	$wp_customize->add_setting('footer|padding',
		array(
			'transport' => 'postMessage',
			'default' => '15px'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'footer|padding',
			array(
				'label' => 'PADDING',
				'type' => 'select',
				'section' => 'footer',
				'settings'=> 'footer|padding',
                'choices' => array(
                    '0px' => '0px', '5px' => '5px', '10px' => '10px', '15px' => '15px', '20px' => '20px', '25px' => '25px', '30px' => '30px'
			     )
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('footer|padding',
		array(
			'selector' => 'p.footer_padding',
			'settings' => 'footer|padding',
			'render_callback' => function() {
				return get_theme_mod('footer|padding');
			},
		)
	);
		
}

add_action('customize_register', 'customize_register_footer');


function after_setup_theme_footer(){
	file_log(__FILE__, __LINE__, __FUNCTION__, 'begin ');
    
	function footer_scripts(){
        wp_enqueue_style('footer', get_stylesheet_directory_uri().'/style/css/footer.css');
	}
    
	add_action('wp_enqueue_scripts', 'footer_scripts', 100);
	
	function footer_action(){
        $cnt = did_action('zerif_after_footer');
        if( $cnt == 1 ) {
            get_template_part('sections/footer');
        }
	}
	
	add_action('zerif_after_footer',  'footer_action');
}

add_action('after_setup_theme', 'after_setup_theme_footer');
