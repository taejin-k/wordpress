<?php

function widgets_features_02(){
    file_log( __FILE__, __LINE__, __FUNCTION__, 'begin' );
    $id = 'sidebar_features_02';
    
    register_sidebar(
        array (
            'name'          => 'FEATURES 02',
            'id'            => $id,
            'before_widget' => '<p id="%1$s">',
            'after_widget'  => '</p>',
        )
    );
    is_active_sidebar($id);
}
add_action('widgets_init', 'widgets_features_02');


function user_define_register_widget_features_02(){
    register_widget('features_02_content_widget');
}
add_action('widgets_init', 'user_define_register_widget_features_02');


class features_02_content_widget extends WP_Widget {
    function __construct(){
        parent::__construct(
            'feature_02_content_widget',
            'FEATURE 02 CONTENT',
            array('description' => 'FEATURE 02 내용 위젯')

        );
        add_action( 'admin_enqueue_scripts', array( $this, 'widget_scripts' ) );
    }
    
    function update( $new_instance, $old_instance ) {
        $instance                        = $old_instance;
        $instance['text']                = $new_instance['text'];
        $instance['title']               = $new_instance['title'];
        $instance['title_color']         = $new_instance['title_color'];
        $instance['content_color']       = $new_instance['content_color'];
        $instance['icon_uri']            = $new_instance['icon_uri'];
        $instance['image_uri']           = $new_instance['image_uri'];
        $instance['custom_media_id']     = $new_instance['custom_media_id'];
        $instance['image_in_customizer'] = $new_instance['image_in_customizer'];
        return $instance;

    }

    function widget($args, $instance){

        echo $args['before_widget'];

        ?>    

        <div class="h-column h-column-container d-flex h-col-lg-4 h-col-md-6 h-col-12 style-635-outer style-local-5-c56-outer">
            <div data-colibri-id="5-c56" class="d-flex h-flex-basis h-column__inner h-px-lg-0 h-px-md-0 h-px-0 v-inner-lg-0 v-inner-md-0 v-inner-0 style-635 style-local-5-c56 position-relative" style="background-image: url(<?php if( isset($instance['image_uri']) ){echo esc_url( $instance['image_uri'] );}?>);">
                <div class="w-100 h-y-container h-column__content h-column__v-align flex-basis-100 align-self-lg-start align-self-md-start align-self-start">
                    <div data-colibri-id="5-c57" class="h-row-container gutters-row-lg-0 gutters-row-md-0 gutters-row-0 gutters-row-v-lg-0 gutters-row-v-md-0 gutters-row-v-0 style-629 style-local-5-c57 position-relative">
                        <div class="h-row justify-content-lg-center justify-content-md-center justify-content-center align-items-lg-stretch align-items-md-stretch align-items-stretch gutters-col-lg-0 gutters-col-md-0 gutters-col-0 gutters-col-v-lg-0 gutters-col-v-md-0 gutters-col-v-0">
                            <div class="h-column h-column-container d-flex h-col-lg-12 h-col-md-12 h-col-12 style-630-outer style-local-5-c58-outer">
                                <div data-colibri-id="5-c58" class="d-flex h-flex-basis h-column__inner h-px-lg-3 h-px-md-3 h-px-3 v-inner-lg-3 v-inner-md-3 v-inner-3 style-630 style-local-5-c58 position-relative">
                                    <div class="w-100 h-y-container h-column__content h-column__v-align flex-basis-100 align-self-lg-start align-self-md-start align-self-start">
                                        <div data-colibri-id="5-c59" class="h-icon style-631 style-local-5-c59 position-relative h-element">
                                            <span class="h-svg-icon h-icon__icon style-631-icon style-local-5-c59-icon" style="background: url(<?php if( isset($instance['icon_uri']) ){ echo $instance['icon_uri']; }?>) no-repeat center; background-size: cover;">
                                                
                                            </span>
                                        </div>
                                        <div data-colibri-id="5-c60" class="h-global-transition-all h-heading style-632 style-local-5-c60 position-relative h-element">
                                            <div class="h-heading__outer style-632 style-local-5-c60">
                                                <h4 class="" style="color: <?php if( isset($instance['title_color']) ){ echo $instance['title_color']; }?>"><?php if( isset($instance['title']) ){ echo $instance['title']; }?></h4>
                                            </div>
                                        </div>
                                        <div data-colibri-id="5-c61" class="h-text h-text-component style-633 style-local-5-c61 position-relative h-element">
                                            <div class="">
                                                <p style="color: <?php if( isset($instance['content_color']) ){ echo $instance['content_color']; }?>"><?php if( isset($instance['text']) ){ echo $instance['text']; }?></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php

        echo $args['after_widget'];

    }

    function form( $instance ) {
        ?>
        
        <p>
            <label class="customize-control-title">제목</label>
            <input type="text" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php if ( ! empty( $instance['title'] ) ): echo $instance['title']; endif; ?>" class="widefat">
        </p>
        <p>
            <label class="customize-control-title">제목 색깔</label>
            <input type="color" name="<?php echo $this->get_field_name( 'title_color' ); ?>" value="<?php if ( ! empty( $instance['title_color'] ) ): echo $instance['title_color']; endif; ?>" class="widefat content_color" style="width: 60px; height: 25px;">
        </p>
        <p>
            <label class="customize-control-title">내용</label>
            <textarea class="widefat" rows="4" cols="20" name="<?php echo $this->get_field_name( 'text' ); ?>"><?php if ( ! empty( $instance['text'] ) ): echo htmlspecialchars_decode( $instance['text'] ); endif; ?></textarea>
        </p>
        <p>
            <label class="customize-control-title">내용 색깔</label>
            <input type="color" name="<?php echo $this->get_field_name( 'content_color' ); ?>" value="<?php if ( ! empty( $instance['content_color'] ) ): echo $instance['content_color']; endif; ?>" class="widefat content_color" style="width: 60px; height: 25px;">
        </p>
        <p>
            <label class="customize-control-title">아이콘 이미지</label>
            <?php
            $image_in_customizer = '';
            $display             = 'none';
            if ( ! empty( $instance['image_in_customizer'] ) && ! empty( $instance['image_uri'] ) ) {
                $image_in_customizer = esc_url( $instance['image_in_customizer'] );
                $display             = 'inline-block';
            } else {
                if ( ! empty( $instance['icon_uri'] ) ) {
                    $image_in_customizer = esc_url( $instance['icon_uri'] );
                    $display             = 'inline-block';
                }
            }
            $zerif_image_in_customizer = $this->get_field_name( 'image_in_customizer' );
            ?>
            <input type="hidden" class="custom_media_display_in_customizer"
                   name="<?php if ( ! empty( $zerif_image_in_customizer ) ) {
                       echo $zerif_image_in_customizer;
                   } ?>"
                   value="<?php if ( ! empty( $instance['image_in_customizer'] ) ): echo $instance['image_in_customizer']; endif; ?>">
            <img class="custom_media_image" src="<?php echo $image_in_customizer; ?>"
                 style="margin:0;padding:0;max-width:100px;float:left;display:<?php echo $display; ?>"
                 alt="<?php echo __( 'Uploaded icon', 'zerif-lite' ); ?>"/>

            <input type="text" class="widefat custom_media_url"
                   name="<?php echo $this->get_field_name( 'icon_uri' ); ?>"
                   value="<?php if ( ! empty( $instance['icon_uri'] ) ): echo $instance['icon_uri']; endif; ?>"
                   style="margin-top:5px;">

            <input type="button" class="button button-primary custom_media_button" id="custom_media_button"
                   name="<?php echo $this->get_field_name( 'icon_uri' ); ?>"
                   value="<?php _e( 'Upload Icon', 'zerif-lite' ); ?>" style="margin-top:5px;">
        </p>
        <p>
            <label class="customize-control-title">이미지</label>
            <?php
            $image_in_customizer = '';
            $display             = 'none';
            if ( ! empty( $instance['image_in_customizer'] ) && ! empty( $instance['image_uri'] ) ) {
                $image_in_customizer = esc_url( $instance['image_in_customizer'] );
                $display             = 'inline-block';
            } else {
                if ( ! empty( $instance['image_uri'] ) ) {
                    $image_in_customizer = esc_url( $instance['image_uri'] );
                    $display             = 'inline-block';
                }
            }
            $zerif_image_in_customizer = $this->get_field_name( 'image_in_customizer' );
            ?>
            <input type="hidden" class="custom_media_display_in_customizer"
                   name="<?php if ( ! empty( $zerif_image_in_customizer ) ) {
                       echo $zerif_image_in_customizer;
                   } ?>"
                   value="<?php if ( ! empty( $instance['image_in_customizer'] ) ): echo $instance['image_in_customizer']; endif; ?>">
            <img class="custom_media_image" src="<?php echo $image_in_customizer; ?>"
                 style="margin:0;padding:0;max-width:100px;float:left;display:<?php echo $display; ?>"
                 alt="<?php echo __( 'Uploaded image', 'zerif-lite' ); ?>"/>

            <input type="text" class="widefat custom_media_url"
                   name="<?php echo $this->get_field_name( 'image_uri' ); ?>"
                   value="<?php if ( ! empty( $instance['image_uri'] ) ): echo $instance['image_uri']; endif; ?>"
                   style="margin-top:5px;">

            <input type="button" class="button button-primary custom_media_button" id="custom_media_button"
                   name="<?php echo $this->get_field_name( 'image_uri' ); ?>"
                   value="<?php _e( 'Upload Image', 'zerif-lite' ); ?>" style="margin-top:5px;">
        </p>

        <input class="custom_media_id" id="<?php echo $this->get_field_id( 'custom_media_id' ); ?>"
               name="<?php echo $this->get_field_name( 'custom_media_id' ); ?>" type="hidden"
               value="<?php if ( ! empty( $instance["custom_media_id"] ) ): echo $instance["custom_media_id"]; endif; ?>"/>

        <?php

    }
    
    function widget_scripts( $hook ) {
        if ( $hook != 'widgets.php' ) {
            return;
        }
        wp_enqueue_media();
        wp_enqueue_script( 'zerif_widget_media_script', get_template_directory_uri() . '/js/widget-media.js', false, '1.1', true );
    }


}


function customize_register_features_02($wp_customize){
	file_log(__FILE__, __LINE__, __FUNCTION__, 'begin ');
    
    // FEATURES -> FEATURES 02
    $wp_customize->add_section('features|02',
        array(
            'title' => 'FEATURE 02',
        )
    );
    
    // FEATURES -> FEATURES 02 -> 숨기기
	$wp_customize->add_setting('features|02|hide',
		array(
			'transport' => 'postMessage',
			'default' => false,
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'features|02|hide',
			array(
				'label' => '숨기기',
				'type' => 'checkbox',
				'section' => 'features|02',
				'settings'=> 'features|02|hide',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('features|02|hide',
		array(
			'selector' => 'div.features_02_hide',
			'settings' => 'features|02|hide',
			'render_callback' => function() {
				return get_theme_mod('features|02|hide');
			},
		)
	);
    
    // FEATURES -> FEATURES 02 -> 제목
	$wp_customize->add_setting('features|02|title',
		array(
			'transport' => 'postMessage',
			'default' => '로또코치 이용'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'features|02|title',
			array(
				'label' => '제목',
				'type' => 'text',
				'section' => 'features|02',
				'settings'=> 'features|02|title',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('features|02|title',
		array(
			'selector' => 'h2.features_02_title',
			'settings' => 'features|02|title',
			'render_callback' => function() {
				return get_theme_mod('features|02|title');
			},
		)
	);
    
    // FEATURES -> FEATURES 02 -> 제목 색깔
	$wp_customize->add_setting('features|02|title_color',
		array(
			'default' => '#17252a'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control($wp_customize, 'features|02|title_color',
			array(
				'label' => '제목 색깔',
				'section' => 'features|02',
				'settings'=> 'features|02|title_color',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('features|02|title_color',
		array(
			'selector' => 'div.features_02_title_color',
			'settings' => 'features|02|title_color',
		)
	);

	// FEATURES -> FEATURES 02 -> 부제목
	$wp_customize->add_setting( 'features|02|sub_title',
		array(
			'transport' => 'postMessage',
			'default' => '로또복권번호가 궁금하신가요? 이제 간편하게 로또코치 하세요.'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'features|02|sub_title',
			array(
				'label' => '부제목',
				'type' => 'text',
				'section' => 'features|02',
				'settings'=> 'features|02|sub_title',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('features|02|sub_title',
		array(
			'selector' => 'p.features_02_sub_title',
			'settings' => 'features|02|sub_title',
			'render_callback' => function() {
				return get_theme_mod('features|02|sub_title');
			},
		)
	);
    
    // FEATURES -> FEATURES 02 -> 부제목 색깔
	$wp_customize->add_setting('features|02|sub_title_color',
		array(
			'default' => '#17252a'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control($wp_customize, 'features|02|sub_title_color',
			array(
				'label' => '부제목 색깔',
				'section' => 'features|02',
				'settings'=> 'features|02|sub_title_color',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('features|02|sub_title_color',
		array(
			'selector' => 'p.features_02_sub_title_color',
			'settings' => 'features|02|sub_title_color',
		)
	);
    
    // FEATURES -> FEATURES 02 -> 배경 색깔
	$wp_customize->add_setting('features|02|background_color',
		array(
			'default' => '#F5FAFD'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control($wp_customize, 'features|02|background_color',
			array(
				'label' => '배경 색깔',
				'section' => 'features|02',
				'settings'=> 'features|02|background_color',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('features|02|background_color',
		array(
			'selector' => 'div.features_02_background_color',
			'settings' => 'features|02|background_color',
		)
	);
    
        // FEATURES -> FEATURES 02 -> PADDING( 1024 < WIDTH )
	$wp_customize->add_setting('features|02|padding_more_than_1024',
		array(
			'transport' => 'postMessage',
			'default' => '90px'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'features|02|padding_more_than_1024',
			array(
				'label' => 'PADDING [1024 < WIDTH]',
				'type' => 'select',
				'section' => 'features|02',
				'settings'=> 'features|02|padding_more_than_1024',
                'choices' => array(
                    '0px' => '0px', '10px' => '10px', '20px' => '20px', '30px' => '30px', '40px' => '40px', '50px' => '50px', '60px' => '60px', '70px' => '70px', '80px' => '80px', '90px' => '90px', '100px' => '100px', '110px' => '110px', '120px' => '120px',  '130px' => '130px', '140px' => '140px', '150px' => '150px', '160px' => '160px', '170px' => '170px', '180px' => '180px', '190px' => '190px', '200px' => '200px'
			     )
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('features|02|padding_more_than_1024',
		array(
			'selector' => 'p.features_02_padding_more_than_1024',
			'settings' => 'features|02|padding_more_than_1024',
			'render_callback' => function() {
				return get_theme_mod('features|02|padding_more_than_1024');
			},
		)
	);
    
    // FEATURES -> FEATURES 02 -> PADDING( 768 < WIDTH < 1024 )
	$wp_customize->add_setting('features|02|padding_more_than_768',
		array(
			'transport' => 'postMessage',
			'default' => '60px'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'features|02|padding_more_than_768',
			array(
				'label' => 'PADDING [768 < WIDTH < 1024]',
				'type' => 'select',
				'section' => 'features|02',
				'settings'=> 'features|02|padding_more_than_768',
                'choices' => array(
                    '0px' => '0px', '10px' => '10px', '20px' => '20px', '30px' => '30px', '40px' => '40px', '50px' => '50px', '60px' => '60px', '70px' => '70px', '80px' => '80px', '90px' => '90px', '100px' => '100px', '110px' => '110px', '120px' => '120px',  '130px' => '130px', '140px' => '140px', '150px' => '150px', '160px' => '160px', '170px' => '170px', '180px' => '180px', '190px' => '190px', '200px' => '200px'
			     )
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('features|02|padding_more_than_768',
		array(
			'selector' => 'p.features_02_padding_more_than_768',
			'settings' => 'features|02|padding_more_than_768',
			'render_callback' => function() {
				return get_theme_mod('features|02|padding_more_than_768');
			},
		)
	);
    
    // FEATURES -> FEATURES 02 -> PADDING( 0 < WIDTH < 768 )
	$wp_customize->add_setting('features|02|padding_more_than_0',
		array(
			'transport' => 'postMessage',
			'default' => '30px'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'features|02|padding_more_than_0',
			array(
				'label' => 'PADDING [0 < WIDTH < 768]',
				'type' => 'select',
				'section' => 'features|02',
				'settings'=> 'features|02|padding_more_than_0',
                'choices' => array(
                    '0px' => '0px', '10px' => '10px', '20px' => '20px', '30px' => '30px', '40px' => '40px', '50px' => '50px', '60px' => '60px', '70px' => '70px', '80px' => '80px', '90px' => '90px', '100px' => '100px', '110px' => '110px', '120px' => '120px',  '130px' => '130px', '140px' => '140px', '150px' => '150px', '160px' => '160px', '170px' => '170px', '180px' => '180px', '190px' => '190px', '200px' => '200px'
			     )
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('features|02|padding_more_than_0',
		array(
			'selector' => 'p.features_02_padding_more_than_0',
			'settings' => 'features|02|padding_more_than_0',
			'render_callback' => function() {
				return get_theme_mod('features|02|padding_more_than_0');
			},
		)
	);
    
    // 위젯 추가
    $section_id = 'sidebar-widgets-sidebar_features_02';
    $widget_section = $wp_customize->get_section( $section_id );
    
    if(!empty($widget_section)) {
        
        // 패널
        $widget_section->panel                                        = 'features';
        $widget_section->title                                        = 'FEATURES 02';
        $widget_section->priority                                     = 2;
            
        // 숨기기
        $wp_customize->get_control( 'features|02|hide' )->section     = $section_id;
        $wp_customize->get_control( 'features|02|hide' )->priority    = -1;
        
        // 제목
        $wp_customize->get_control( 'features|02|title' )->section     = $section_id;
        $wp_customize->get_control( 'features|02|title' )->priority    = -1;
        
        // 제목 색깔
        $wp_customize->get_control( 'features|02|title_color' )->section     = $section_id;
        $wp_customize->get_control( 'features|02|title_color' )->priority    = -1;
        
        // 부제목
        $wp_customize->get_control( 'features|02|sub_title' )->section     = $section_id;
        $wp_customize->get_control( 'features|02|sub_title' )->priority    = -1;
        
        // 부제목 색깔
        $wp_customize->get_control( 'features|02|sub_title_color' )->section     = $section_id;
        $wp_customize->get_control( 'features|02|sub_title_color' )->priority    = -1;
        
        // 배경 색깔
        $wp_customize->get_control( 'features|02|background_color' )->section     = $section_id;
        $wp_customize->get_control( 'features|02|background_color' )->priority    = -1;
        
        // PADDING( 1024 < WIDTH )
        $wp_customize->get_control( 'features|02|padding_more_than_1024' )->section     = $section_id;
        $wp_customize->get_control( 'features|02|padding_more_than_1024' )->priority    = -1;
        
        // PADDING( 768 < WIDTH < 1024 )
        $wp_customize->get_control( 'features|02|padding_more_than_768' )->section     = $section_id;
        $wp_customize->get_control( 'features|02|padding_more_than_768' )->priority    = -1;
        
        // PADDING( 0 < WIDTH < 768 )
        $wp_customize->get_control( 'features|02|padding_more_than_0' )->section     = $section_id;
        $wp_customize->get_control( 'features|02|padding_more_than_0' )->priority    = -1;
    
    }
}

add_action('customize_register', 'customize_register_features_02');


function after_setup_theme_features_02() {
	file_log(__FILE__, __LINE__, __FUNCTION__, 'begin ');
    
	function features_02_scripts(){
        wp_enqueue_script('features_02', get_stylesheet_directory_uri().'/js/feature_02.js', array(), false, true);
	}
    
	add_action('wp_enqueue_scripts', 'features_02_scripts', 100);
	
	function features_02_action() {
        $cnt = did_action('zerif_after_header');
        if( $cnt == 1 ) {
            get_template_part('sections/features_02');
        }
	}
	
	add_action('zerif_after_header',  'features_02_action');
}

add_action('after_setup_theme', 'after_setup_theme_features_02');
