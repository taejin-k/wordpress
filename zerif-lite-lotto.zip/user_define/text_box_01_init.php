<?php

function customize_register_text_box_01($wp_customize){
	file_log(__FILE__, __LINE__, __FUNCTION__, 'begin ');
    
    // TEXT BOX
    $wp_customize->add_panel('text_box',
        array(
            'title' => 'TEXT BOX',
            'description' => 'TEXT BOX 관련 설정을 합니다.',
        )
    );

    // TEXT BOX -> TEXT BOX 01
    $wp_customize->add_section('text_box|01',
        array(
            'title' => 'TEXT BOX 01',
            'panel' => 'text_box',
            'priority' => 1
        )
    );
    
    // TEXT BOX -> TEXT BOX 01 -> 숨기기
	$wp_customize->add_setting('text_box|01|hide',
		array(
			'transport' => 'postMessage',
			'default' => false,
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'text_box|01|hide',
			array(
				'label' => '숨기기',
				'type' => 'checkbox',
				'section' => 'text_box|01',
				'settings'=> 'text_box|01|hide',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('text_box|01|hide',
		array(
			'selector' => 'section.text_box_01_hide',
			'settings' => 'text_box|01|hide',
			'render_callback' => function() {
				return get_theme_mod('text_box|01|hide');
			},
		)
	);
    
    // TEXT BOX -> TEXT BOX 01 -> 제목
	$wp_customize->add_setting('text_box|01|title',
		array(
			'transport' => 'postMessage',
			'default' => '로또 당첨은 <span class="span_pointer">승부</span>입니다'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'text_box|01|title',
			array(
				'label' => '제목',
                'description' => '강조가 필요한 곳에 span class="span_pointer" 태그를 삽입해주세요.',
				'type' => 'text',
				'section' => 'text_box|01',
				'settings'=> 'text_box|01|title',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('text_box|01|title',
		array(
			'selector' => 'p.text_box_01_title',
			'settings' => 'text_box|01|title',
			'render_callback' => function() {
				return get_theme_mod('text_box|01|title');
			},
		)
	);
    
    // TEXT BOX -> TEXT BOX 01 -> 제목 색깔
	$wp_customize->add_setting('text_box|01|title_color',
		array(
			'default' => '#fff'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control($wp_customize, 'text_box|01|title_color',
			array(
				'label' => '제목 색깔',
				'section' => 'text_box|01',
				'settings'=> 'text_box|01|title_color',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('text_box|01|title_color',
		array(
			'selector' => 'p.text_box_01_title_color',
			'settings' => 'text_box|01|title_color',
		)
	);
    
    // TEXT BOX -> TEXT BOX 01 -> 제목 강조 색깔
	$wp_customize->add_setting('text_box|01|title_point_color',
		array(
			'default' => '#de5665'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control($wp_customize, 'text_box|01|title_point_color',
			array(
				'label' => '제목 강조 색깔',
				'section' => 'text_box|01',
				'settings'=> 'text_box|01|title_point_color',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('text_box|01|title_point_color',
		array(
			'selector' => 'span.text_box_01_title_point_color',
			'settings' => 'text_box|01|title_point_color',
		)
	);
    
    // TEXT BOX -> TEXT BOX 01 -> 부제목
	$wp_customize->add_setting('text_box|01|sub_title',
		array(
			'transport' => 'postMessage',
			'default' => '이번주 로또 1등 당첨자는 <span class="sub_span_pointer">바로 당신</span>입니다.'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'text_box|01|sub_title',
			array(
				'label' => '부제목',
                'description' => '강조가 필요한 곳에 span class="sub_span_pointer" 태그를 삽입해주세요.',
				'type' => 'text',
				'section' => 'text_box|01',
				'settings'=> 'text_box|01|sub_title',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('text_box|01|sub_title',
		array(
			'selector' => 'p.text_box_01_sub_title',
			'settings' => 'text_box|01|sub_title',
			'render_callback' => function() {
				return get_theme_mod('text_box|01|sub_title');
			},
		)
	);
    
    // TEXT BOX -> TEXT BOX 01 -> 부제목 색깔
	$wp_customize->add_setting('text_box|01|sub_title_color',
		array(
			'default' => '#fff'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control($wp_customize, 'text_box|01|sub_title_color',
			array(
				'label' => '부제목 색깔',
				'section' => 'text_box|01',
				'settings'=> 'text_box|01|sub_title_color',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('text_box|01|sub_title_color',
		array(
			'settings' => 'text_box|01|sub_title_color',
		)
	);
    
    // TEXT BOX -> TEXT BOX 01 ->  부제목 강조 색깔
	$wp_customize->add_setting('text_box|01|sub_title_point_color',
		array(
			'default' => '#de5665'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control($wp_customize, 'text_box|01|sub_title_point_color',
			array(
				'label' => '부제목 강조 색깔',
				'section' => 'text_box|01',
				'settings'=> 'text_box|01|sub_title_point_color',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('text_box|01|sub_title_point_color',
		array(
			'selector' => 'span.text_box_01_sub_title_point_color',
			'settings' => 'text_box|01|sub_title_point_color',
		)
	);
    
    // TEXT BOX -> TEXT BOX 01 -> 내용
	$wp_customize->add_setting('text_box|01|content',
		array(
			'transport' => 'postMessage',
			'default' => '당첨은 데이터의 승부입니다. 로또 1등 당첨번호를 분석하면, 당신도 로또 1등에 당첨될 수 있습니다.<br> 이제 로또코치를 통해 로또분석번호를 받아보세요. 당신의 인생역전 대박행운의 첫 걸음이 될 것입니다.<br> 이제 간편히 휴대폰으로 로또 당첨번호를 확인하세요.<br> 지금까지 로또 1등 당첨자는 무려 6000명에 달합니다. 아무리 로또 1등 당첨확률이 낮아도 수천명의 사람들이 1등에 당첨되는 행운을 누렸습니다.<br> 그들은 어떻게 1등에 당첨됐을까요? 단순히 운이 좋은사람으로 생각하기에는 너무 많을 것입니다.<br> 심지어 어떤이는 중복으로 여러장의 1등 당첨 기록을 가지고 있죠.<br> 그동안 1등 당첨자들 사이에만 내려오는 분석기법들을 만나보세요.'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'text_box|01|content',
			array(
				'label' => '내용',
                'description' => '줄바꿈이 필요한 곳에 br 태그를 넣어주세요.',
				'type' => 'textarea',
				'section' => 'text_box|01',
				'settings'=> 'text_box|01|content',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('text_box|01|content',
		array(
			'selector' => 'p.text_box_01_content',
			'settings' => 'text_box|01|content',
			'render_callback' => function() {
				return get_theme_mod('text_box|01|content');
			},
		)
	);
    
    // TEXT BOX -> TEXT BOX 01 -> 내용 색깔
	$wp_customize->add_setting('text_box|01|content_color',
		array(
			'default' => '#fff'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control($wp_customize, 'text_box|01|content_color',
			array(
				'label' => '내용 색깔',
				'section' => 'text_box|01',
				'settings'=> 'text_box|01|content_color',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('text_box|01|content_color',
		array(
			'selector' => 'p.text_box_01_content_color',
			'settings' => 'text_box|01|content_color',
		)
	);
    
    // TOP MAIN -> 배경 이미지
	$wp_customize->add_setting('text_box|01|background',
		array(
			'transport' => 'postMessage',
			'default' => 'http://192.168.0.75/wordpress/wp-content/themes/zerif-lite-lotto/img/text_box_01_background.jpg',
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Cropped_Image_Control($wp_customize, 'text_box|01|background',
			array(
				'label' => '배경 이미지',
                'type' => 'image',
                'section' => 'text_box|01',
                'settings' => 'text_box|01|background'
			)
		)
	);
    $wp_customize->selective_refresh->add_partial('text_box|01|background',
		array(
			'selector' => 'section.text_box_01_background',
			'settings' => 'text_box|01|background',
			'render_callback' => function() {
				return get_theme_mod('text_box|01|background');
			},
		)
	);
    
    // TEXT BOX -> TEXT BOX 01 -> PADDING( 1024 < WIDTH )
	$wp_customize->add_setting('text_box|01|padding_more_than_1024',
		array(
			'transport' => 'postMessage',
			'default' => '100px'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'text_box|01|padding_more_than_1024',
			array(
				'label' => 'PADDING [1024 < WIDTH]',
				'type' => 'select',
				'section' => 'text_box|01',
				'settings'=> 'text_box|01|padding_more_than_1024',
                'choices' => array(
                    '0px' => '0px', '10px' => '10px', '20px' => '20px', '30px' => '30px', '40px' => '40px', '50px' => '50px', '60px' => '60px', '70px' => '70px', '80px' => '80px', '90px' => '90px', '100px' => '100px', '110px' => '110px', '120px' => '120px',  '130px' => '130px', '140px' => '140px', '150px' => '150px', '160px' => '160px', '170px' => '170px', '180px' => '180px', '190px' => '190px', '200px' => '200px'
			     )
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('text_box|01|padding_more_than_1024',
		array(
			'selector' => 'p.text_box_01_padding_more_than_1024',
			'settings' => 'text_box|01|padding_more_than_1024',
			'render_callback' => function() {
				return get_theme_mod('text_box|01|padding_more_than_1024');
			},
		)
	);
    
    // TEXT BOX -> TEXT BOX 02 -> PADDING( 480 < WIDTH < 1024 )
	$wp_customize->add_setting('text_box|01|padding_more_than_480',
		array(
			'transport' => 'postMessage',
			'default' => '60px'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'text_box|01|padding_more_than_480',
			array(
				'label' => 'PADDING [480 < WIDTH < 1024]',
				'type' => 'select',
				'section' => 'text_box|01',
				'settings'=> 'text_box|01|padding_more_than_480',
                'choices' => array(
                    '0px' => '0px', '10px' => '10px', '20px' => '20px', '30px' => '30px', '40px' => '40px', '50px' => '50px', '60px' => '60px', '70px' => '70px', '80px' => '80px', '90px' => '90px', '100px' => '100px', '110px' => '110px', '120px' => '120px',  '130px' => '130px', '140px' => '140px', '150px' => '150px', '160px' => '160px', '170px' => '170px', '180px' => '180px', '190px' => '190px', '200px' => '200px'
			     )
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('text_box|01|padding_more_than_480',
		array(
			'selector' => 'p.text_box_01_padding_more_than_480',
			'settings' => 'text_box|01|padding_more_than_480',
			'render_callback' => function() {
				return get_theme_mod('text_box|01|padding_more_than_480');
			},
		)
	);
    
    // TEXT BOX -> TEXT BOX 02 -> PADDING( 0 < WIDTH < 480 )
	$wp_customize->add_setting('text_box|01|padding_more_than_0',
		array(
			'transport' => 'postMessage',
			'default' => '40px'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'text_box|01|padding_more_than_0',
			array(
				'label' => 'PADDING [0 < WIDTH < 480]',
				'type' => 'select',
				'section' => 'text_box|01',
				'settings'=> 'text_box|01|padding_more_than_0',
                'choices' => array(
                    '0px' => '0px', '10px' => '10px', '20px' => '20px', '30px' => '30px', '40px' => '40px', '50px' => '50px', '60px' => '60px', '70px' => '70px', '80px' => '80px', '90px' => '90px', '100px' => '100px', '110px' => '110px', '120px' => '120px',  '130px' => '130px', '140px' => '140px', '150px' => '150px', '160px' => '160px', '170px' => '170px', '180px' => '180px', '190px' => '190px', '200px' => '200px'
			     )
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('text_box|01|padding_more_than_0',
		array(
			'selector' => 'p.text_box_01_padding_more_than_0',
			'settings' => 'text_box|01|padding_more_than_0',
			'render_callback' => function() {
				return get_theme_mod('text_box|01|padding_more_than_0');
			},
		)
	);

}

add_action('customize_register', 'customize_register_text_box_01');


function after_setup_theme_text_box_01() {
	file_log(__FILE__, __LINE__, __FUNCTION__, 'begin ');
    
	function text_box_01_scripts(){
        wp_enqueue_style('text_box_01', get_stylesheet_directory_uri().'/style/css/text_box_01.css');
	}
    
	add_action('wp_enqueue_scripts', 'text_box_01_scripts', 100);
	
	function text_box_01_action() {
        $cnt = did_action('zerif_after_header');
        if( $cnt == 1 ) {
            get_template_part('sections/text_box_01');
        }
	}
	
	add_action('zerif_after_header',  'text_box_01_action');
}

add_action('after_setup_theme', 'after_setup_theme_text_box_01');
