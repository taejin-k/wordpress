<?php

function customize_register_top_main($wp_customize){
	file_log(__FILE__, __LINE__, __FUNCTION__, 'begin ');

    // TOP MAIN
    $wp_customize->add_section('top_main',
        array(
            'title' => 'TOP MAIN',
            'description' => 'TOP MAIN 관련 설정을 합니다.',
        )
    );
    
    // TOP MAIN -> 숨기기
	$wp_customize->add_setting('top_main|hide',
		array(
			'transport' => 'postMessage',
			'default' => false,
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'top_main|hide',
			array(
				'label' => '숨기기',
				'type' => 'checkbox',
				'section' => 'top_main',
				'settings'=> 'top_main|hide',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('top_main|hide',
		array(
			'selector' => 'section.top_main_hide',
			'settings' => 'top_main|hide',
			'render_callback' => function() {
				return get_theme_mod('top_main|hide');
			},
		)
	);
    
    // TOP MAIN -> 제목
	$wp_customize->add_setting('top_main|title',
		array(
			'transport' => 'postMessage',
			'default' => '로또코치를 통해 로또 1등 당첨의<br>든든한 개인코치를 영입해 보세요'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'top_main|title',
			array(
				'label' => '제목',
                'description' => '줄바꿈이 필요한 곳에 br태그를 삽입해주세요.<br>한 줄에 14글자를 넘기지 마세요.',
				'type' => 'text',
				'section' => 'top_main',
				'settings'=> 'top_main|title',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('top_main|title',
		array(
			'selector' => 'p.top_main_title',
			'settings' => 'top_main|title',
			'render_callback' => function() {
				return get_theme_mod('top_main|title');
			},
		)
	);
    
    // TOP MAIN -> 제목 색깔
	$wp_customize->add_setting('top_main|title_color',
		array(
			'default' => '#fff'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control($wp_customize, 'top_main|title_color',
			array(
				'label' => '제목 색깔',
				'section' => 'top_main',
				'settings'=> 'top_main|title_color',
			)
		)
	);
    $wp_customize->selective_refresh->add_partial('top_main|title_color',
		array(
			'selector' => 'p.top_main_title_color',
			'settings' => 'top_main|title_color',
			'render_callback' => function() {
				return get_theme_mod('top_main|title_color');
			},
		)
	);
    
    // TOP MAIN -> 부제목
	$wp_customize->add_setting('top_main|sub_title',
		array(
			'transport' => 'postMessage',
			'default' => '이번주 로또 1등 당첨자는 바로 당신입니다'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'top_main|sub_title',
			array(
				'label' => '부제목',
                'description' => '줄바꿈이 필요한 곳에 br태그를 삽입해주세요.<br>한 줄에 22글자를 넘기지 마세요.',
				'type' => 'text',
				'section' => 'top_main',
				'settings'=> 'top_main|sub_title',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('top_main|sub_title',
		array(
			'selector' => 'p.top_main_sub_title',
			'settings' => 'top_main|sub_title',
			'render_callback' => function() {
				return get_theme_mod('top_main|sub_title');
			},
		)
	);
    
    // TOP MAIN -> 부제목 색깔
	$wp_customize->add_setting('top_main|sub_title_color',
		array(
			'default' => '#fff'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control($wp_customize, 'top_main|sub_title_color',
			array(
				'label' => '부제목 색깔',
				'section' => 'top_main',
				'settings'=> 'top_main|sub_title_color',
			)
		)
	);
    $wp_customize->selective_refresh->add_partial('top_main|sub_title_color',
		array(
			'selector' => 'p.top_main_sub_title_color',
			'settings' => 'top_main|sub_title_color',
			'render_callback' => function() {
				return get_theme_mod('top_main|sub_title_color');
			},
		)
	);
    
    // TOP MAIN -> 버튼
	$wp_customize->add_setting('top_main|button',
		array(
			'transport' => 'postMessage',
			'default' => '예약하기'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'top_main|button',
			array(
				'label' => '버튼',
				'type' => 'text',
				'section' => 'top_main',
				'settings'=> 'top_main|button',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('top_main|button',
		array(
			'selector' => 'a.top_main_button',
			'settings' => 'top_main|button',
			'render_callback' => function() {
				return get_theme_mod('top_main|button');
			},
		)
	);
    
    // TOP MAIN -> 버튼 색깔
	$wp_customize->add_setting('top_main|button_color',
		array(
			'default' => '#fff'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control($wp_customize, 'top_main|button_color',
			array(
				'label' => '버튼 색깔',
				'section' => 'top_main',
				'settings'=> 'top_main|button_color',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('top_main|button_color',
		array(
			'selector' => 'a.top_main_button_color',
			'settings' => 'top_main|button_color',
			'render_callback' => function() {
				return get_theme_mod('top_main|button_color');
			},
		)
	);
    
    // TOP MAIN -> 버튼 배경색깔
	$wp_customize->add_setting('top_main|button_background',
		array(
			'default' => '#03a9f4'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control($wp_customize, 'top_main|button_background',
			array(
				'label' => '버튼 배경색깔',
				'section' => 'top_main',
				'settings'=> 'top_main|button_background',
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('top_main|button_background',
		array(
			'selector' => 'a.top_main_button_background',
			'settings' => 'top_main|button_background',
			'render_callback' => function() {
				return get_theme_mod('top_main|button_background');
			},
		)
	);
    
    // TOP MAIN -> 배경 이미지
	$wp_customize->add_setting('top_main|background',
		array(
			'transport' => 'postMessage',
			'default' => 'http://192.168.0.75/wordpress/wp-content/themes/zerif-lite-lotto/img/top_main_background.png',
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Cropped_Image_Control($wp_customize, 'top_main|background',
			array(
				'label' => '배경 이미지',
                'type' => 'image',
                'section' => 'top_main',
                'settings' => 'top_main|background'
			)
		)
	);
    $wp_customize->selective_refresh->add_partial('top_main|background',
		array(
			'selector' => 'section.top_main_background',
			'settings' => 'top_main|background',
			'render_callback' => function() {
				return get_theme_mod('top_main|background');
			},
		)
	);
    
    // TOP MAIN -> 배경 이미지 명암
	$wp_customize->add_setting('top_main|background_contrast',
		array(
			'transport' => 'postMessage',
			'default' => '0.5',
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'top_main|background_contrast',
			array(
				'label' => '배경 이미지 명암',
                'type' => 'select',
                'section' => 'top_main',
                'settings' => 'top_main|background_contrast',
                'choices' => array(
                    '0' => '0', '0.1' => '0.1', '0.2' => '0.2', '0.3' => '0.3', '0.4' => '0.4', '0.5' => '0.5', '0.6' => '0.6', '0.7' => '0.7', '0.8' => '0.8', '0.9' => '0.9', '1' => '1'
			     )
			)
		)
	);
    $wp_customize->selective_refresh->add_partial('top_main|background_contrast',
		array(
			'selector' => 'div.top_main_background_contrast',
			'settings' => 'top_main|background_contrast',
			'render_callback' => function() {
				return get_theme_mod('top_main|background_contrast');
			},
		)
	);
    
    // TOP MAIN -> PADDING( 1024 < WIDTH )
	$wp_customize->add_setting('top_main|padding_more_than_1024',
		array(
			'transport' => 'postMessage',
			'default' => '360px'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'top_main|padding_more_than_1024',
			array(
				'label' => 'PADDING [1024 < WIDTH]',
				'type' => 'select',
				'section' => 'top_main',
				'settings'=> 'top_main|padding_more_than_1024',
                'choices' => array(
                    '0px' => '0px', '10px' => '10px', '20px' => '20px', '30px' => '30px', '40px' => '40px', '50px' => '50px', '60px' => '60px', '70px' => '70px', '80px' => '80px', '90px' => '90px', '100px' => '100px', '110px' => '110px', '120px' => '120px',  '130px' => '130px', '140px' => '140px', '150px' => '150px', '160px' => '160px', '170px' => '170px', '180px' => '180px', '190px' => '190px', '200px' => '200px', '210px' => '210px', '220px' => '220px', '230px' => '230px', '240px' => '240px', '250px' => '250px', '260px' => '260px', '270px' => '270px', '280px' => '280px', '290px' => '290px', '300px' => '300px', '310px' => '310px', '320px' => '320px', '330px' => '330px', '340px' => '340px', '350px' => '350px', '360px' => '360px'
			     )
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('top_main|padding_more_than_1024',
		array(
			'selector' => 'p.top_main_padding_more_than_1024',
			'settings' => 'top_main|padding_more_than_1024',
			'render_callback' => function() {
				return get_theme_mod('top_main|padding_more_than_1024');
			},
		)
	);
    
    // TOP MAIN -> PADDING( 768 < WIDTH < 1024 )
	$wp_customize->add_setting('top_main|padding_more_than_768',
		array(
			'transport' => 'postMessage',
			'default' => '300px'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'top_main|padding_more_than_768',
			array(
				'label' => 'PADDING [768 < WIDTH < 1024]',
				'type' => 'select',
				'section' => 'top_main',
				'settings'=> 'top_main|padding_more_than_768',
                'choices' => array(
                    '0px' => '0px', '10px' => '10px', '20px' => '20px', '30px' => '30px', '40px' => '40px', '50px' => '50px', '60px' => '60px', '70px' => '70px', '80px' => '80px', '90px' => '90px', '100px' => '100px', '110px' => '110px', '120px' => '120px',  '130px' => '130px', '140px' => '140px', '150px' => '150px', '160px' => '160px', '170px' => '170px', '180px' => '180px', '190px' => '190px', '200px' => '200px', '210px' => '210px', '220px' => '220px', '230px' => '230px', '240px' => '240px', '250px' => '250px', '260px' => '260px', '270px' => '270px', '280px' => '280px', '290px' => '290px', '300px' => '300px', '310px' => '310px', '320px' => '320px', '330px' => '330px', '340px' => '340px', '350px' => '350px', '360px' => '360px'
			     )
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('top_main|padding_more_than_768',
		array(
			'selector' => 'p.top_main_padding_more_than_768',
			'settings' => 'top_main|padding_more_than_768',
			'render_callback' => function() {
				return get_theme_mod('top_main|padding_more_than_768');
			},
		)
	);
    
    // TOP MAIN -> PADDING( 560 < WIDTH < 768 )
	$wp_customize->add_setting('top_main|padding_more_than_560',
		array(
			'transport' => 'postMessage',
			'default' => '300px'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'top_main|padding_more_than_560',
			array(
				'label' => 'PADDING [560 < WIDTH < 768]',
				'type' => 'select',
				'section' => 'top_main',
				'settings'=> 'top_main|padding_more_than_560',
                'choices' => array(
                    '0px' => '0px', '10px' => '10px', '20px' => '20px', '30px' => '30px', '40px' => '40px', '50px' => '50px', '60px' => '60px', '70px' => '70px', '80px' => '80px', '90px' => '90px', '100px' => '100px', '110px' => '110px', '120px' => '120px',  '130px' => '130px', '140px' => '140px', '150px' => '150px', '160px' => '160px', '170px' => '170px', '180px' => '180px', '190px' => '190px', '200px' => '200px', '210px' => '210px', '220px' => '220px', '230px' => '230px', '240px' => '240px', '250px' => '250px', '260px' => '260px', '270px' => '270px', '280px' => '280px', '290px' => '290px', '300px' => '300px', '310px' => '310px', '320px' => '320px', '330px' => '330px', '340px' => '340px', '350px' => '350px', '360px' => '360px'
			     )
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('top_main|padding_more_than_560',
		array(
			'selector' => 'p.top_main_padding_more_than_560',
			'settings' => 'top_main|padding_more_than_560',
			'render_callback' => function() {
				return get_theme_mod('top_main|padding_more_than_560');
			},
		)
	);
    
    // TOP MAIN -> PADDING( 420 < WIDTH < 560 )
	$wp_customize->add_setting('top_main|padding_more_than_420',
		array(
			'transport' => 'postMessage',
			'default' => '240px'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'top_main|padding_more_than_420',
			array(
				'label' => 'PADDING [420 < WIDTH < 560]',
				'type' => 'select',
				'section' => 'top_main',
				'settings'=> 'top_main|padding_more_than_420',
                'choices' => array(
                    '0px' => '0px', '10px' => '10px', '20px' => '20px', '30px' => '30px', '40px' => '40px', '50px' => '50px', '60px' => '60px', '70px' => '70px', '80px' => '80px', '90px' => '90px', '100px' => '100px', '110px' => '110px', '120px' => '120px',  '130px' => '130px', '140px' => '140px', '150px' => '150px', '160px' => '160px', '170px' => '170px', '180px' => '180px', '190px' => '190px', '200px' => '200px', '210px' => '210px', '220px' => '220px', '230px' => '230px', '240px' => '240px', '250px' => '250px', '260px' => '260px', '270px' => '270px', '280px' => '280px', '290px' => '290px', '300px' => '300px', '310px' => '310px', '320px' => '320px', '330px' => '330px', '340px' => '340px', '350px' => '350px', '360px' => '360px'
			     )
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('top_main|padding_more_than_420',
		array(
			'selector' => 'p.top_main_padding_more_than_420',
			'settings' => 'top_main|padding_more_than_420',
			'render_callback' => function() {
				return get_theme_mod('top_main|padding_more_than_420');
			},
		)
	);
    
    // TOP MAIN -> PADDING( 360 < WIDTH < 420 )
	$wp_customize->add_setting('top_main|padding_more_than_360',
		array(
			'transport' => 'postMessage',
			'default' => '210px'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'top_main|padding_more_than_360',
			array(
				'label' => 'PADDING [360 < WIDTH < 420]',
				'type' => 'select',
				'section' => 'top_main',
				'settings'=> 'top_main|padding_more_than_360',
                'choices' => array(
                    '0px' => '0px', '10px' => '10px', '20px' => '20px', '30px' => '30px', '40px' => '40px', '50px' => '50px', '60px' => '60px', '70px' => '70px', '80px' => '80px', '90px' => '90px', '100px' => '100px', '110px' => '110px', '120px' => '120px',  '130px' => '130px', '140px' => '140px', '150px' => '150px', '160px' => '160px', '170px' => '170px', '180px' => '180px', '190px' => '190px', '200px' => '200px', '210px' => '210px', '220px' => '220px', '230px' => '230px', '240px' => '240px', '250px' => '250px', '260px' => '260px', '270px' => '270px', '280px' => '280px', '290px' => '290px', '300px' => '300px', '310px' => '310px', '320px' => '320px', '330px' => '330px', '340px' => '340px', '350px' => '350px', '360px' => '360px'
			     )
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('top_main|padding_more_than_360',
		array(
			'selector' => 'p.top_main_padding_more_than_360',
			'settings' => 'top_main|padding_more_than_360',
			'render_callback' => function() {
				return get_theme_mod('top_main|padding_more_than_360');
			},
		)
	);
    
    // TOP MAIN -> PADDING( 0 < WIDTH < 360 )
	$wp_customize->add_setting('top_main|padding_more_than_0',
		array(
			'transport' => 'postMessage',
			'default' => '200px'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Control($wp_customize, 'top_main|padding_more_than_0',
			array(
				'label' => 'PADDING [0 < WIDTH < 360]',
				'type' => 'select',
				'section' => 'top_main',
				'settings'=> 'top_main|padding_more_than_0',
                'choices' => array(
                    '0px' => '0px', '10px' => '10px', '20px' => '20px', '30px' => '30px', '40px' => '40px', '50px' => '50px', '60px' => '60px', '70px' => '70px', '80px' => '80px', '90px' => '90px', '100px' => '100px', '110px' => '110px', '120px' => '120px',  '130px' => '130px', '140px' => '140px', '150px' => '150px', '160px' => '160px', '170px' => '170px', '180px' => '180px', '190px' => '190px', '200px' => '200px', '210px' => '210px', '220px' => '220px', '230px' => '230px', '240px' => '240px', '250px' => '250px', '260px' => '260px', '270px' => '270px', '280px' => '280px', '290px' => '290px', '300px' => '300px', '310px' => '310px', '320px' => '320px', '330px' => '330px', '340px' => '340px', '350px' => '350px', '360px' => '360px'
			     )
			)
		)
	);
	$wp_customize->selective_refresh->add_partial('top_main|padding_more_than_0',
		array(
			'selector' => 'p.top_main_padding_more_than_0',
			'settings' => 'top_main|padding_more_than_0',
			'render_callback' => function() {
				return get_theme_mod('top_main|padding_more_than_0');
			},
		)
	);
    
}

add_action('customize_register', 'customize_register_top_main');

function after_setup_theme_top_main(){
    
	file_log(__FILE__, __LINE__, __FUNCTION__, 'begin ');
    
	function top_main_scripts(){
        wp_enqueue_style('top_main', get_stylesheet_directory_uri().'/style/css/top_main.css');
        wp_enqueue_script('top_main', get_stylesheet_directory_uri().'/js/top_main.js', array(), false, true);
	}
    
	add_action('wp_enqueue_scripts', 'top_main_scripts', 100);
	
	function top_main_action(){
        $cnt = did_action('zerif_after_header');
        if( $cnt == 1 ) {
            get_template_part('sections/top_main');
        }
	}
	
	add_action('zerif_after_header',  'top_main_action');
}

add_action('after_setup_theme', 'after_setup_theme_top_main');
