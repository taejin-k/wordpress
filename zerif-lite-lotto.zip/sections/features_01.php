<style>
    #features_01{padding: <?php echo get_theme_mod('features|01|padding_more_than_0', '30px'); ?> <?php echo '0'; ?>;}
    @media screen and (min-width: 768px){
        #features_01{padding: <?php echo get_theme_mod('features|01|padding_more_than_768', '60px'); ?> <?php echo '0'; ?>}
    }
    @media screen and (min-width: 1024px){
        #features_01{padding: <?php echo get_theme_mod('features|01|padding_more_than_1024', '90px'); ?> <?php echo '0'; ?>;}
    }
</style>
<div data-colibri-component="section" data-colibri-id="5-c12" class="h-section h-section-global-spacing d-flex align-items-lg-center align-items-md-center align-items-center style-612 style-local-5-c12 position-relative" <?php if( get_theme_mod('features|01|hide') == 1) { echo 'style="display: none;"'; }?> id="features_01" style="background: <?php echo get_theme_mod('features|01|background_color', '#fff'); ?>">
    <div class="h-section-grid-container h-section-boxed-container" style="max-width: 95%;">
        <div data-colibri-id="5-c38" class="h-row-container gutters-row-lg-2 gutters-row-md-2 gutters-row-0 gutters-row-v-lg-2 gutters-row-v-md-2 gutters-row-v-2 style-622 style-local-5-c38 position-relative">
            <div class="h-row justify-content-lg-center justify-content-md-center justify-content-center align-items-lg-stretch align-items-md-stretch align-items-stretch gutters-col-lg-2 gutters-col-md-2 gutters-col-0 gutters-col-v-lg-2 gutters-col-v-md-2 gutters-col-v-2">
                <div class="h-column h-column-container d-flex h-col-lg-auto h-col-md-auto h-col-auto style-623-outer style-local-5-c39-outer">
                    <div data-colibri-id="5-c39" class="d-flex h-flex-basis h-column__inner h-px-lg-2 h-px-md-2 h-px-2 v-inner-lg-2 v-inner-md-2 v-inner-2 style-623 style-local-5-c39 position-relative">
                        <div class="w-100 h-y-container h-column__content h-column__v-align flex-basis-100 align-self-lg-start align-self-md-start align-self-start">
                            <div data-colibri-id="5-c40" class="h-global-transition-all h-heading style-624 style-local-5-c40 position-relative h-element">
                                <div class="h-heading__outer style-624 style-local-5-c40" style="color: <?php echo get_theme_mod('features|01|title_color', '#474747'); ?>">
                                    <h2 class="features_01_title" style="font-weight: bold;"><?php echo get_theme_mod('features|01|title', '로또코치 자주하는 질문'); ?></h2>
                                </div>
                            </div>
                            <div data-colibri-id="5-c41" class="h-lead h-text h-text-component style-625 style-local-5-c41 position-relative h-element">
                                <div class="" style="color: <?php echo get_theme_mod('features|01|sub_title_color', '#474747'); ?>">
                                    <p class="features_01_sub_title features_01_sub_title_color"><?php echo get_theme_mod('features|01|sub_title', '이제 로또코치를 통해 로또 1등 당첨의 든든한 개인코치를 영입해 보세요.'); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div data-colibri-id="5-c13" class="h-row-container gutters-row-lg-2 gutters-row-md-2 gutters-row-2 gutters-row-v-lg-2 gutters-row-v-md-2 gutters-row-v-2 style-613 style-local-5-c13 position-relative" style="text-align: left;">
            <div class="h-row justify-content-lg-center justify-content-md-center justify-content-center align-items-lg-stretch align-items-md-stretch align-items-stretch gutters-col-lg-2 gutters-col-md-2 gutters-col-2 gutters-col-v-lg-2 gutters-col-v-md-2 gutters-col-v-2">

                <?php
                if ( is_active_sidebar( 'sidebar_features_01' ) ) : 
                    dynamic_sidebar( 'sidebar_features_01' );
                endif;
                ?>
                
            </div>
        </div>
    </div>
</div>