<div class="lotto_free_number_popup" api_url="<?php echo get_theme_mod('lotto|free_number_popup|api_url', 'https://free.onedaynice.co.kr/complete.php?cmpny=lottoanalysis&to=b');?>" <?php if( get_theme_mod('lotto|free_number_popup|hide') == 1) { echo 'style="display: none;"'; }?>>
	<div class="formWrap">
		<div>
			<span></span>
			<input type="tel" id="PHONE_POPUP" placeholder="휴대폰 번호를 입력해주세요">
			<input type="text" id="NAME_POPUP" placeholder="이름을 입력해주세요">
		</div>
		<div>
			<div style="position: relative;">
				<p class="lotto_free_number_popup_privacy">
				    <input type="checkbox" id="checkbox_popup" style="vertical-align: middle;" checked>
				    <label for="checkbox_popup">개인정보 취급동의</label>
                </p>
			</div>
			<p class="lotto_free_number_popup_submit">
			    <button type="button" id="button_popup"><?php echo get_theme_mod('lotto|free_number_popup|submit', '실시간 무료번호 받기');?></button>
			</p>
			
		</div>
	</div>
</div>
