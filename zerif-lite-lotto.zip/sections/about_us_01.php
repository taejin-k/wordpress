<style>
    .em_pointer{color: <?php echo get_theme_mod('about_us|01|sub_title_point_color', '#03a9f4'); ?>}
</style>
<style>
    #about_us_01{padding: <?php echo get_theme_mod('about_us|01|padding_more_than_0', '30px'); ?> <?php echo '0'; ?>;}
    @media screen and (min-width: 768px){
        #about_us_01{padding: <?php echo get_theme_mod('about_us|01|padding_more_than_768', '60px'); ?> <?php echo '0'; ?>}
    }
    @media screen and (min-width: 1024px){
        #about_us_01{padding: <?php echo get_theme_mod('about_us|01|padding_more_than_1024', '90px'); ?> <?php echo '0'; ?>;}
    }
</style>
<div data-colibri-component="section" data-colibri-id="5-c251" class="h-section h-section-global-spacing d-flex align-items-lg-center align-items-md-center align-items-center style-602 style-local-5-c251 position-relative about_us_01_background_color" <?php if( get_theme_mod('about_us|01|hide') == 1) { echo 'style="display: none;"'; }?> id="about_us_01" style="background: <?php echo get_theme_mod('about_us|01|background_color', '#F5FAFD'); ?>">
    <div class="h-section-grid-container h-section-boxed-container">
        <div data-colibri-id="5-c252" class="h-row-container gutters-row-lg-2 gutters-row-md-2 gutters-row-2 gutters-row-v-lg-2 gutters-row-v-md-2 gutters-row-v-2 style-603 style-local-5-c252 position-relative">
            <div class="h-row justify-content-lg-center justify-content-md-center justify-content-center align-items-lg-stretch align-items-md-stretch align-items-stretch gutters-col-lg-2 gutters-col-md-2 gutters-col-2 gutters-col-v-lg-2 gutters-col-v-md-2 gutters-col-v-2">
                <div class="h-column h-column-container d-flex h-col-lg-auto h-col-md-auto h-col-auto style-604-outer style-local-5-c253-outer">
                    <div data-colibri-id="5-c253" class="d-flex h-flex-basis h-column__inner h-px-lg-2 h-px-md-2 h-px-2 v-inner-lg-2 v-inner-md-2 v-inner-2 style-604 style-local-5-c253 position-relative">
                        <div class="w-100 h-y-container h-column__content h-column__v-align flex-basis-100 align-self-lg-center align-self-md-center align-self-center">
                            <div data-colibri-id="5-c254" class="h-global-transition-all h-heading style-605 style-local-5-c254 position-relative h-element">
                                <div class="h-heading__outer style-605 style-local-5-c254" style="color: <?php echo get_theme_mod('about_us|01|title_color', '#333'); ?>">
                                    <h3 class="about_us_01_title about_us_01_title_color" style="font-weight: bold;"><?php echo get_theme_mod('about_us|01|title', '로또코치 시스템소개'); ?></h3>
                                </div>
                            </div>
                            <div data-colibri-id="5-c255" class="h-global-transition-all h-heading style-606 style-local-5-c255 position-relative h-element">
                                <div class="h-heading__outer style-606 style-local-5-c255" style="color: <?php echo get_theme_mod('about_us|01|sub_title_color', '#333'); ?>">
                                    <h3 class="about_us_01_sub_title"><?php echo get_theme_mod('about_us|01|sub_title', '로또코치의 시스템은 지난 로또 <em class="em_pointer">당첨번호</em>들의 <em class="em_pointer">통계</em>를 기반으로 합니다.'); ?></h3>
                                </div>
                            </div>
                            <div data-colibri-id="5-c256" class="h-lead h-text h-text-component style-607 style-local-5-c256 position-relative h-element">
                                <div class="about_us_01_content_color" style="color: <?php echo get_theme_mod('about_us|01|content_color', '#25292a'); ?>">
                                    <p style="line-height: 1.9; color: inherit;" class="about_us_01_content"><?php echo get_theme_mod('about_us|01|content', '지난 번호들을 고급 통계시스템을 통해 회원들에게 제공됩니다. 이는 기존 로또 당첨번호를 토대로 당첨확률이 낮다고 판단되는 번호를 제외시키기 때문입니다. 이를 통해 로또1등, 로또2등 당첨 등의 고액 로또 당첨이 가능합니다.'); ?></p>
                                </div>
                            </div>
                            <div data-colibri-id="5-c257" class="h-x-container style-608 style-local-5-c257 position-relative h-element">
                                <div class="h-x-container-inner style-dynamic-5-c257-group style-608-spacing style-local-5-c257-spacing">
                                    <span class="h-button__outer style-609-outer style-local-5-c258-outer d-inline-flex h-element">
                                        <a h-use-smooth-scroll="true" href="#lotto_free_number"data-colibri-id="5-c258" class="d-flex w-100 align-items-center h-button justify-content-lg-center justify-content-md-center justify-content-center style-609 style-local-5-c258 position-relative preventD" style="color: <?php echo get_theme_mod('about_us|01|button_color', '#fff'); ?>; background: <?php echo get_theme_mod('about_us|01|button_background', '#03a9f4'); ?>; border: none;">
                                            <span class="about_us_01_button"><?php echo get_theme_mod('about_us|01|button', '무료번호받기'); ?></span>
                                        </a>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="h-column h-column-container d-flex h-col-lg-auto h-col-md-auto h-col-auto style-610-outer style-local-5-c259-outer">
                    <div data-colibri-id="5-c259" class="d-flex h-flex-basis h-column__inner h-px-lg-2 h-px-md-2 h-px-2 v-inner-lg-2 v-inner-md-2 v-inner-2 style-610 style-local-5-c259 position-relative">
                        <div class="w-100 h-y-container h-column__content h-column__v-align flex-basis-100 align-self-lg-center align-self-md-center align-self-center">
                            <div data-colibri-id="5-c260" class="d-block style-611 style-local-5-c260 position-relative h-element">
                                <div class="h-image__frame-container-outer">
                                    <div class="h-image__frame-container">
                                        <img src="<?php echo get_theme_mod('about_us|01|image', 'https://user-63680339-work.colibriwp.com/sample-project/wp-content/uploads/2021/01/colibri-image-320.png'); ?>" class="wp-image-1488 style-611-image style-local-5-c260-image about_us_01_image" alt="" />
                                        <div class="h-image__frame h-hide-sm style-611-frameImage style-local-5-c260-frameImage about_us_01_image_border" style="border-color: <?php echo get_theme_mod('about_us|01|image_border', '#03a9f4'); ?>"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>