<style>
    #features_02{padding: <?php echo get_theme_mod('features|02|padding_more_than_0', '30px'); ?> <?php echo '0'; ?>;}
    @media screen and (min-width: 768px){
        #features_02{padding: <?php echo get_theme_mod('features|02|padding_more_than_768', '60px'); ?> <?php echo '0'; ?>}
    }
    @media screen and (min-width: 1024px){
        #features_02{padding: <?php echo get_theme_mod('features|02|padding_more_than_1024', '90px'); ?> <?php echo '0'; ?>;}
    }
</style>
<div data-colibri-component="section" data-colibri-id="5-c42" class="h-section h-section-global-spacing d-flex align-items-lg-center align-items-md-center align-items-center style-626 style-local-5-c42 position-relative features_02_background_color" <?php if( get_theme_mod('features|02|hide') == 1) { echo 'style="display: none;"'; }?> id="features_02" style="background: <?php echo get_theme_mod('features|02|background_color', '#F5FAFD') ?> !important;">
    <div class="h-section-grid-container h-section-boxed-container" style="max-width: 95%;">
        <div data-colibri-id="5-c62" class="h-row-container gutters-row-lg-2 gutters-row-md-2 gutters-row-2 gutters-row-v-lg-2 gutters-row-v-md-2 gutters-row-v-2 style-636 style-local-5-c62 position-relative">
            <div class="h-row justify-content-lg-center justify-content-md-center justify-content-center align-items-lg-stretch align-items-md-stretch align-items-stretch gutters-col-lg-2 gutters-col-md-2 gutters-col-2 gutters-col-v-lg-2 gutters-col-v-md-2 gutters-col-v-2">
                <div class="h-column h-column-container d-flex h-col-lg-auto h-col-md-auto h-col-auto style-637-outer style-local-5-c63-outer">
                    <div data-colibri-id="5-c63" class="d-flex h-flex-basis h-column__inner h-px-lg-2 h-px-md-2 h-px-2 v-inner-lg-2 v-inner-md-2 v-inner-2 style-637 style-local-5-c63 position-relative">
                        <div class="w-100 h-y-container h-column__content h-column__v-align flex-basis-100 align-self-lg-start align-self-md-start align-self-start">
                            <div data-colibri-id="5-c64" class="h-global-transition-all h-heading style-638 style-local-5-c64 position-relative h-element">
                                <div class="h-heading__outer style-638 style-local-5-c64" style="color: <?php echo get_theme_mod('features|02|title_color', '#17252a'); ?>">
                                    <h2 class="features_02_title" style="font-weight: bold; color: inherit;"><?php echo get_theme_mod('features|02|title', '로또코치 이용'); ?></h2>
                                </div>
                            </div>
                            <div data-colibri-id="5-c65" class="h-lead h-text h-text-component style-639 style-local-5-c65 position-relative h-element">
                                <div class="">
                                    <p class="features_02_sub_title features_02_sub_title" style="color: <?php echo get_theme_mod('features|02|sub_title_color', '#17252a'); ?>">
                                        <?php echo get_theme_mod('features|02|sub_title', '로또복권번호가 궁금하신가요? 이제 간편하게 로또코치 하세요.'); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div data-colibri-id="5-c43" class="h-row-container gutters-row-lg-2 gutters-row-md-2 gutters-row-2 gutters-row-v-lg-2 gutters-row-v-md-2 gutters-row-v-2 style-627 style-local-5-c43 position-relative">
            <div class="h-row justify-content-lg-center justify-content-md-center justify-content-center align-items-lg-stretch align-items-md-stretch align-items-stretch gutters-col-lg-2 gutters-col-md-2 gutters-col-2 gutters-col-v-lg-2 gutters-col-v-md-2 gutters-col-v-2">
                

                <?php
                if ( is_active_sidebar( 'sidebar_features_02' ) ) : 
                    dynamic_sidebar( 'sidebar_features_02' );
                endif;
                ?>

            </div>
        </div>
    </div>
</div>