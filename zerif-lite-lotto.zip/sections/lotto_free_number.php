<style>
    .lotto_free_number{display: block; width: 100%; padding: <?php echo get_theme_mod('lotto|free_number|padding_more_than_0', '60px'); ?> <?php echo '0'; ?>; text-align: center;}
    @media screen and (min-width: 768px){
	    .lotto_free_number{padding: <?php echo get_theme_mod('lotto|free_number|padding_more_than_768', '80px'); ?> <?php echo '0'; ?>;}
    }
</style>
<section class="lotto_free_number" id="lotto_free_number" api_url="<?php echo get_theme_mod('lotto|free_number|api_url', 'https://free.onedaynice.co.kr/complete.php?cmpny=lottoanalysis&to=b');?>" <?php if( get_theme_mod('lotto|free_number|hide') == 1) { echo 'style="display: none;"'; }?> style="background: <?php echo get_theme_mod('lotto|free_number|color', '#51b6d9'); ?>">
	<div class="container sectionWrap">
		<p class="lotto_free_number_title lotto_free_number_title_color" style="color: <?php echo get_theme_mod('lotto|free_number|title_color', '#fff'); ?>"><?php echo get_theme_mod('lotto|free_number|title', '실시간 무료번호 받기'); ?></p>
		<p class="lotto_free_number_sub_title lotto_free_number_sub_title_color" style="color: <?php echo get_theme_mod('lotto|free_number|sub_title_color', '#fff'); ?>"><?php echo get_theme_mod('lotto|free_number|sub_title', '지금 당신의 행운번호를 만나보세요.');?></p>
		<div>
			<input type="tel" id="PHONE" placeholder="휴대폰 번호를 입력해주세요">
			<input type="text" id="NAME" placeholder="이름을 입력해주세요">
			<p class="lotto_free_number_privacy lotto_free_number_privacy_color"><input type="checkbox" id="checkbox" checked><label for="checkbox" style="color: <?php echo get_theme_mod('lotto|free_number|privacy_color', '#fff'); ?>">개인정보 취급동의</label></p>
		</div>
		<p class="lotto_free_number_submit">
		    <button type="button" id="button" class="lotto_free_number_submit_color lotto_free_number_submit_background_color" style="color: <?php echo get_theme_mod('lotto|free_number|submit_color', '#fff'); ?>; background: <?php echo get_theme_mod('lotto|free_number|submit_background_color', '#383838'); ?>"><?php echo get_theme_mod('lotto|free_number|submit', '무료번호받기');?></button>
		</p>
	</div>
</section>
