<style>
    .top_main{display: block; width: 100%; padding: <?php echo get_theme_mod('top_main|padding_more_than_1024', '360px'); ?> <?php echo '0px'; ?>; position: relative;}
    @media screen and (max-width: 1024px){
        .top_main{padding: <?php echo get_theme_mod('top_main|padding_more_than_768', '300px'); ?> <?php echo '0px'; ?>;}
    }
    @media screen and (max-width: 768px){
        .top_main{padding: <?php echo get_theme_mod('top_main|padding_more_than_560', '300px'); ?> <?php echo '0px'; ?>;}
    }
    @media screen and (max-width: 560px){
	.top_main{padding: <?php echo get_theme_mod('top_main|padding_more_than_420', '240px'); ?> <?php echo '0px'; ?>;}
    }
    @media screen and (max-width: 420px){
        .top_main{padding: <?php echo get_theme_mod('top_main|padding_more_than_360', '210px'); ?> <?php echo '0px'; ?>;}
    }
    @media screen and (max-width: 360px){
        .top_main{padding: <?php echo get_theme_mod('top_main|padding_more_than_0', '200px'); ?> <?php echo '0px'; ?>;}
    }
</style>
<section class="top_main" id="top_main" <?php if( get_theme_mod('top_main|hide') == 1) { echo 'style="display: none;"'; }?> style="background: url(<?php echo get_theme_mod('top_main|background', 'http://192.168.0.75/wordpress/wp-content/themes/zerif-lite-lotto/img/top_main_background.png'); ?>) no-repeat center; background-size: cover;">
    <div class="background" style="background: rgba(0, 0, 0, <?php echo get_theme_mod('top_main|background_contrast', '0.5'); ?>);"></div>
    <div class="sectionWrap">
        <p class="top_main_title" style="color: <?php echo get_theme_mod('top_main|title_color', '#fff'); ?>">
            <?php echo get_theme_mod('top_main|title', '로또코치를 통해 로또 1등 당첨의<br>든든한 개인코치를 영입해 보세요'); ?>
        </p>
        <p class="top_main_sub_title" style="color: <?php echo get_theme_mod('top_main|sub_title_color', '#fff'); ?>">
            <?php echo get_theme_mod('top_main|sub_title', '이번주 로또 1등 당첨자는 바로 당신입니다'); ?>
        </p>
        <a class="preventD top_main_button" href="#lotto_free_number" style="color: <?php echo get_theme_mod('top_main|button_color', '#fff'); ?>; background: <?php echo get_theme_mod('top_main|button_background', '#03a9f4'); ?>">
            <?php echo get_theme_mod('top_main|button', '예약하기'); ?>
        </a>
    </div>
</section>