<style>
    .lotto_winner_number{width: 100%; padding: <?php echo get_theme_mod('lotto|winner_number|padding_more_than_0', '40px'); ?> <?php echo '0px'; ?>; background: #fff; text-align: center; transition: .4s; background: #f5f5f5;}
    @media screen and (min-width: 480px){
        .lotto_winner_number{padding: <?php echo get_theme_mod('lotto|winner_number|padding_more_than_480', '60px'); ?> <?php echo '5%'; ?>;}
    }
    @media screen and (min-width: 640px){
        .lotto_winner_number{padding: <?php echo get_theme_mod('lotto|winner_number|padding_more_than_640', '80px'); ?> <?php echo '5%'; ?>;}
    }
    @media screen and (min-width: 1024px){
        .lotto_winner_number{padding: <?php echo get_theme_mod('lotto|winner_number|padding_more_than_1024', '100px'); ?> <?php echo '5%'; ?>;}
    }
</style>
<section class="lotto_winner_number" id="lotto_winner_number" api_url="<?php echo get_theme_mod('lotto|winner_number|api_url', 'https://lottoblue.co.kr/json/module_lotto.php');?>" <?php if( get_theme_mod('lotto|winner_number|hide') == 1) { echo 'style="display: none;"'; }?> style="background: <?php echo get_theme_mod('lotto|winner_number|color', '#f5f5f5'); ?>">
	<div class="container sectionWrap lotto_winner_number_text_color" style="color: <?php echo get_theme_mod('lotto|winner_number|text_color', '#474747'); ?>">
		<p><span id="ln_year"></span>.<span id="ln_month"></span>.<span id="ln_date"></span> 추첨</p>
		<p><img src="https://lottoanalysis.co.kr/wp-content/uploads/2019/08/left.png" id="left"><span id="ln_number" style="color: <?php echo get_theme_mod('lotto|winner_number|number_color', '#d5230f'); ?>" class="lotto_winner_number_number_color"></span>회 로또당첨번호<img src="https://lottoanalysis.co.kr/wp-content/uploads/2019/08/right.png" id="right"></p>
		<p>
			<span class="counter" id="first_number"></span>
			<span class="counter" id="second_number"></span>
			<span class="counter" id="third_number"></span>
			<span class="counter" id="fourth_number"></span>
			<span class="counter" id="fifth_number"></span>
			<span class="counter" id="sixth_number"></span>
			<span class="image"><img src="https://lottoanalysis.co.kr/wp-content/uploads/2019/08/plus.png" alt="플러스"></span>
			<span class="counter" id="seventh_number"></span>
		</p>
		<div>
			<span>1등 당첨자 <span id="winner" class="lotto_winner_number_text_point_color" style="color: <?php echo get_theme_mod('lotto|winner_number|text_point_color', '#e64135'); ?>"></span>명</span>
			<span>당첨금액 <span id="winner_money" class="lotto_winner_number_text_point_color" style="color: <?php echo get_theme_mod('lotto|winner_number|text_point_color', '#e64135'); ?>"></span>원</span>
		</div>
	</div>
</section>

