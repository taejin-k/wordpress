<style>
    .text_box_02_span_pointer{font-weight: bold; color: <?php echo get_theme_mod('text_box|02|title_pointer_color', '#474747'); ?>}
    .text_box_02_sub_span_pointer{color: <?php echo get_theme_mod('text_box|02|sub_title_pointer_color', '#474747'); ?>}
</style>
<style>
    .text_box_02{width: 100%; padding: <?php echo get_theme_mod('lotto|winner_number|padding_more_than_0', '40px'); ?> <?php echo '5%'; ?>; background: #f5f5f5; text-align: center; transition: .4s;}
    @media screen and (min-width: 480px){
        .text_box_02{padding: <?php echo get_theme_mod('lotto|winner_number|padding_more_than_480', '60px'); ?> <?php echo '5%'; ?>}
    }
    @media screen and (min-width: 768px){
        .text_box_02{padding: <?php echo get_theme_mod('lotto|winner_number|padding_more_than_768', '80px'); ?> <?php echo '5%'; ?>;}
    }
</style>
<section class="text_box_02" id="text_box_02" <?php if( get_theme_mod('text_box|02|hide') == 1) { echo 'style="display: none;"'; }?> style="background: <?php echo get_theme_mod('text_box|02|color', '#fff'); ?>">
    <div class="sectionWrap">
        <p class="text_box_02_title" style="color: <?php echo get_theme_mod('text_box|02|title_color', '#474747'); ?>">
            <?php echo get_theme_mod('text_box|02|title', '<span class="text_box_02_span_pointer">위젯</span>을 사용해 내용을 추가하세요.'); ?>
        </p>
        <div style="background: url(<?php echo get_theme_mod('text_box|02|image', 'http://192.168.0.75/wordpress/wp-content/themes/zerif-lite-lotto/img/text_box_02_image.jpg'); ?>) no-repeat center; background-size: cover;"></div>
        
        <?php
        if ( is_active_sidebar( 'sidebar_text_box_02' ) ) : 
            dynamic_sidebar( 'sidebar_text_box_02' );
        endif;
        ?>
        
        <p class="lastText text_box_02_sub_title" style="color: <?php echo get_theme_mod('text_box|02|sub_title_color', '#3cadd4'); ?>">
            <?php echo get_theme_mod('text_box|02|sub_title', '이제 AI시스템을 통해 향상된 <span class="text_box_02_sub_span_pointer">로또번호</span>를 무료로 사용해보세요.'); ?>
        </p>
    </div>
</section>