<style>
    .footer{padding: <?php echo get_theme_mod('footer|padding', '15px'); ?> <?php echo '0'; ?>;}
</style>
<section class="footer" <?php if( get_theme_mod('footer|hide') == 1) { echo 'style="display: none;"'; }?> style="background: <?php echo get_theme_mod('footer|background_color', '#383b43'); ?>">
    <div class="sectionWrap">
        <p class="footer_text" style="color: <?php echo get_theme_mod('footer|text_color', '#fff'); ?>">
            <?php echo get_theme_mod('footer|text', '&copy; copyright by LottoCoach<br>상호명: 로또코치 &nbsp; 이메일: lottocoachhelp@gmail.com'); ?>
        </p>
    </div>
</section>