<style>
    .span_pointer{color: <?php echo get_theme_mod('text_box|01|title_point_color', '#de5665'); ?>}
    .sub_span_pointer{color: <?php echo get_theme_mod('text_box|01|sub_title_point_color', '#de5665'); ?>}
</style>
<style>
    .text_box_01{padding: <?php echo get_theme_mod('text_box|01|padding_more_than_0', '40px'); ?> <?php echo '5%'; ?>;}
    @media screen and (min-width: 480px){
        .text_box_01{padding: <?php echo get_theme_mod('text_box|01|padding_more_than_480', '60px'); ?> <?php echo '5%'; ?>}
    }
    @media screen and (min-width: 1024px){
        .text_box_01{padding: <?php echo get_theme_mod('text_box|01|padding_more_than_1024', '100px'); ?> <?php echo '5%'; ?>;}
    }
</style>
<section class="text_box_01" <?php if( get_theme_mod('text_box|01|hide') == 1) { echo 'style="display: none;"'; }?> style="background: url(<?php echo get_theme_mod('text_box|01|background', 'http://192.168.0.75/wordpress/wp-content/themes/zerif-lite-lotto/img/text_box_01_background.jpg'); ?>) no-repeat center; background-size: cover;">
    <div class="sectionWrap">
        <p class="text_box_01_title text_box_01_title_color" style="color: <?php echo get_theme_mod('text_box|01|title_color', '#fff'); ?>">
            <?php echo get_theme_mod('text_box|01|title', '로또 당첨은 <span class="span_pointer">승부</span>입니다'); ?>
        </p>
        <p class="text_box_01_content_color" style="color: <?php echo get_theme_mod('text_box|01|content_color', '#fff'); ?>">
            <?php echo get_theme_mod('text_box|01|content', '당첨은 데이터의 승부입니다. 로또 1등 당첨번호를 분석하면, 당신도 로또 1등에 당첨될 수 있습니다.<br> 이제 로또코치를 통해 로또분석번호를 받아보세요. 당신의 인생역전 대박행운의 첫 걸음이 될 것입니다.<br> 이제 간편히 휴대폰으로 로또 당첨번호를 확인하세요.<br> 지금까지 로또 1등 당첨자는 무려 6000명에 달합니다. 아무리 로또 1등 당첨확률이 낮아도 수천명의 사람들이 1등에 당첨되는 행운을 누렸습니다.<br> 그들은 어떻게 1등에 당첨됐을까요? 단순히 운이 좋은사람으로 생각하기에는 너무 많을 것입니다.<br> 심지어 어떤이는 중복으로 여러장의 1등 당첨 기록을 가지고 있죠.<br> 그동안 1등 당첨자들 사이에만 내려오는 분석기법들을 만나보세요.'); ?>
        </p>
        <p class="text_box_01_sub_title text_box_01_sub_title_color" style="color: <?php echo get_theme_mod('text_box|01|sub_title_color', '#fff'); ?>">
            <?php echo get_theme_mod('text_box|01|sub_title', '이번주 로또 1등 당첨자는 <span class="sub_span_pointer">바로 당신</span>입니다.'); ?>
        </p>
    </div>
</section>