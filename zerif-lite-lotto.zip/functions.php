<?php

// log
function file_log( $file, $line, $function, $msg ) {
	$msg2 = date("Y-m-d H:i:s", strtotime('9 hour')).' | '.sprintf("%-29.29s", basename($file)).' | '.sprintf("%-27.27s", $function).' | '.sprintf("%-4d", $line).' | '.$msg.PHP_EOL;
    error_log( $msg2, 3, get_stylesheet_directory().'/log.log');
}


// zerif lite parent style
function parent_style_css(){ 
	wp_enqueue_style('style-parent-css', get_template_directory_uri().'/style.css');
}
add_action('wp_enqueue_scripts', 'parent_style_css'); 

// zerif lite child parent style
function child_style_css(){ 
	wp_enqueue_style('style-chlld-css', get_stylesheet_directory_uri().'/style.css', array('style-parent-css'));
}
add_action('wp_enqueue_scripts', 'child_style_css');


// TOP MAIN
require_once get_stylesheet_directory()."/user_define/top_main_init.php";

// 로또당첨번호
require_once get_stylesheet_directory()."/user_define/lotto_winner_number_init.php";

// TEXT BOX 02
require_once get_stylesheet_directory()."/user_define/text_box_02_init.php";

// ABOUT US 01
require_once get_stylesheet_directory()."/user_define/about_us_01_init.php";

// 무료번호받기
require_once get_stylesheet_directory()."/user_define/lotto_free_number_init.php";

// FEATURES 01
require_once get_stylesheet_directory()."/user_define/features_01_init.php";

// TEXT BOX 01
require_once get_stylesheet_directory()."/user_define/text_box_01_init.php";

// FEATURES 02
require_once get_stylesheet_directory()."/user_define/features_02_init.php";

// 무료번호받기 - 팝업
require_once get_stylesheet_directory()."/user_define/lotto_free_number_popup_init.php";

// FOOTER
require_once get_stylesheet_directory()."/user_define/footer_init.php";