<div data-colibri-id="7-h24" class="style-143 style-local-7-h24 position-relative h-element">
  <div class="d-flex flex-wrap h-social-icons justify-content-lg-end justify-content-md-end justify-content-center">
    <?php $component = \ColibriWP\Theme\View::getData( "component" );  $component->printIcons(); ?>
  </div>
</div>
