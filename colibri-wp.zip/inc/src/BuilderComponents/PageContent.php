<?php

namespace ColibriWP\Theme\BuilderComponents;


class PageContent extends \ColibriWP\Theme\Components\PageContent {

}
