<?php get_header(); ?>
<?php colibriwp_theme()->get( 'single' )->render(); ?>
<?php get_footer();
