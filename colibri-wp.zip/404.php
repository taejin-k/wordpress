<?php get_header(); ?>
<?php colibriwp_theme()->get( 'page-not-found' )->render(); ?>
<?php get_footer();
