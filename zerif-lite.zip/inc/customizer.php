<?php

function zerif_customize_register( $wp_customize ) {
	class Zerif_Customize_Textarea_Control extends WP_Customize_Control {
		public $type = 'textarea';

		public function render_content() {
			?>
			<label>
			<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
			<textarea rows="5" style="width:100%;" <?php $this->link(); ?>><?php echo esc_textarea( $this->value() ); ?></textarea>
			</label>
			<?php
		}
	}
	class Zerif_Customizer_Number_Control extends WP_Customize_Control {
		public $type = 'number';
		public function render_content() {
		?>
			<label>
				<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
				<input type="number" <?php $this->link(); ?> value="<?php echo intval( $this->value() ); ?>" />
			</label>
		<?php
		}
	}

	$wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';
	$wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';
	$wp_customize->remove_section('colors');
    
    /**********************************************/
    /****************** LOGO **********************/
	/**********************************************/
    $wp_customize->add_section('logo',
        array(
            'title' => 'LOGO',
            'description' => 'LOGO 관련 설정을 합니다.',
        )
    );
    
    // LOGO
	$wp_customize->add_setting('logo|change',
		array(
			'transport' => 'postMessage',
			'default' => 'http://192.168.0.75/wordpress/wp-content/themes/zerif-lite/images/logo.png',
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Cropped_Image_Control($wp_customize, 'logo|change',
			array(
				'label' => '로고 변경',
                'type' => 'image',
                'section' => 'logo',
                'settings' => 'logo|change'
			)
		)
	);
    $wp_customize->selective_refresh->add_partial('logo|change',
		array(
			'selector' => 'a.logo_change',
			'settings' => 'logo|change',
			'render_callback' => function() {
				return get_theme_mod('logo|change');
			},
		)
	);

	/**********************************************/
    /**********	LATEST NEWS SECTION ***************/
	/**********************************************/
	$wp_customize->add_section( 'zerif_latestnews_section' , array(
		'title'       => __( '최신 글', 'zerif-lite' ),
    	'priority'    => 37
	));

	/* latest news show/hide */
	$wp_customize->add_setting( 'zerif_latestnews_show', array(
		'sanitize_callback' => 'zerif_sanitize_checkbox',
		'transport' => 'postMessage'
	));

    $wp_customize->add_control( 'zerif_latestnews_show', array(
		'type' => 'checkbox',
		'label' => __('Hide latest news section?','zerif-lite'),
		'section' => 'zerif_latestnews_section',
		'priority'    => 1,
	));

	/* latest news title */
	$wp_customize->add_setting( 'zerif_latestnews_title', array(
		'sanitize_callback' => 'zerif_sanitize_input',
		'transport' => 'postMessage'
	));

	$wp_customize->add_control( 'zerif_latestnews_title', array(
		'label'    		=> __( 'Latest News title', 'zerif-lite' ),
		'section'  		=> 'zerif_latestnews_section',
		'priority'    	=> 2,
	));

	/* latest news subtitle */
	$wp_customize->add_setting( 'zerif_latestnews_subtitle', array(
		'sanitize_callback' => 'zerif_sanitize_input',
		'transport' => 'postMessage'
	));

	$wp_customize->add_control( 'zerif_latestnews_subtitle', array(
		'label'    		=> __( 'Latest News subtitle', 'zerif-lite' ),
	    'section'  		=> 'zerif_latestnews_section',
		'priority'   	=> 3,
	));
	
}
add_action( 'customize_register', 'zerif_customize_register' );


function zerif_customize_late_register( $wp_customize ) {

}
add_action( 'customize_register', 'zerif_customize_late_register',999 );
/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
function zerif_customize_preview_js() {
	wp_enqueue_script( 'zerif_customizer', get_template_directory_uri() . '/js/customizer.js', array( 'customize-preview' ), '20130508', true );
}
add_action( 'customize_preview_init', 'zerif_customize_preview_js' );

function zerif_sanitize_input($input ) {
    return wp_kses_post( force_balance_tags( $input ) );
}

function zerif_sanitize_checkbox( $input ){
	return ( isset( $input ) && true == $input ? true : false );
}


function zerif_registers() {

	wp_enqueue_script( 'zerif_customizer_script', get_template_directory_uri() . '/js/zerif_customizer.js', array("jquery"), '1.0.7', true  );

}
add_action( 'customize_controls_enqueue_scripts', 'zerif_registers' );

function zerif_late_registers(){
	wp_enqueue_script( 'zerif_customizer_script', get_template_directory_uri() . '/js/zerif_customizer.js', array("jquery"), '1.0.7', true  );

}
add_action( 'customize_controls_enqueue_scripts', 'zerif_late_registers', 99 );
