/**
 * Theme Customizer enhancements for a better user experience.
 *
 * Contains handlers to make Theme Customizer preview reload changes asynchronously.
 */

( function( $ ) {

	/* Site title and description. */
	wp.customize( 'blogname', function( value ) {
		value.bind( function( to ) {
			$( '.site-title a' ).text( to );
		} );
	} );
	
	wp.customize( 'blogdescription', function( value ) {
		value.bind( function( to ) {
			$( '.site-description' ).text( to );
		} );
	} );
	
	/* Header text color. */
	wp.customize( 'header_textcolor', function( value ) {
		value.bind( function( to ) {
			if ( 'blank' === to ) {
				$( '.site-title, .site-description' ).css( {
					'clip': 'rect(1px, 1px, 1px, 1px)',
					'position': 'absolute'
				} );
			} else {
				$( '.site-title, .site-description' ).css( {
					'clip': 'auto',
					'color': to,
					'position': 'relative'
				} );
			}
		} );
	} );
	
	/********************************************************/
    /************	LATEST NEWS SECTION *********************/
	/********************************************************/

	/* zerif_latestnews_show */
	wp.customize( 'zerif_latestnews_show', function( value ) {
		value.bind( function( to ) {
			if ( '1' != to ) {
				$( 'section.latest-news' ).css( {
					'display': 'block'
				} );
			} else {
				$( 'section.latest-news' ).css( {
					'display': 'none'
				} );
			}
		} );
	} );
	
	/* zerif_latestnews_title */
	wp.customize( 'zerif_latestnews_title', function( value ) {
		value.bind( function( to ) {
			if( to != '' ) {
				$( 'section.latest-news .section-header h2' ).removeClass( 'zerif_hidden_if_not_customizer' );
			}
			else {
				$( 'section.latest-news .section-header h2' ).addClass( 'zerif_hidden_if_not_customizer' );
			}
			$( 'section.latest-news .section-header h2' ).html( to );
		} );
	} );
	
	/* zerif_latestnews_subtitle */
	wp.customize( 'zerif_latestnews_subtitle', function( value ) {
		value.bind( function( to ) {
			if( to != '' ) {
				$( 'section.latest-news .section-header div.section-legend' ).removeClass( 'zerif_hidden_if_not_customizer' );
			}
			else {
				$( 'section.latest-news .section-header div.section-legend' ).addClass( 'zerif_hidden_if_not_customizer' );
			}
			$( 'section.latest-news .section-header div.section-legend' ).html( to );
		} );
	} );

} )( jQuery );